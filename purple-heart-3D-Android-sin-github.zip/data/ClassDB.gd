extends Node
## Clases y habilidades activas únicas.
const CLASSES := {
	"warrior": {"name":"Guerrero","hp":150,"mana":30,"speed":170,"stats":{"str":8,"dex":4,"int":2},
		"skills":[
			{"id":"cleave","name":"Tajo giratorio","cd":4.0,"cost":0,"type":"aoe_melee","dmg":1.5,"radius":70},
			{"id":"shield_bash","name":"Embestida de escudo","cd":8.0,"cost":0,"type":"stun","dmg":0.8,"stun":1.5},
			{"id":"war_cry","name":"Grito de guerra","cd":25.0,"cost":10,"type":"buff_team","buff":"dmg_+20","dur":10}]},
	"mage": {"name":"Mago","hp":80,"mana":150,"speed":160,"stats":{"str":2,"dex":4,"int":10},
		"skills":[
			{"id":"fireball","name":"Bola de fuego","cd":2.5,"cost":15,"type":"projectile","dmg":2.0,"aoe":40},
			{"id":"frost_nova","name":"Nova de hielo","cd":10.0,"cost":30,"type":"aoe_slow","dmg":1.0,"radius":120},
			{"id":"arcane_ward","name":"Barrera arcana","cd":30.0,"cost":50,"type":"shield_team","amount":80}]},
	"archer": {"name":"Arquero","hp":100,"mana":60,"speed":190,"stats":{"str":4,"dex":10,"int":3},
		"skills":[
			{"id":"multishot","name":"Disparo múltiple","cd":3.0,"cost":10,"type":"projectile_fan","dmg":0.8,"count":5},
			{"id":"trap","name":"Trampa de estacas","cd":12.0,"cost":0,"type":"place_trap","dmg":3.0},
			{"id":"piercing","name":"Flecha perforante","cd":6.0,"cost":15,"type":"projectile_pierce","dmg":2.5}]},
	"cleric": {"name":"Clérigo","hp":110,"mana":120,"speed":165,"stats":{"str":3,"dex":3,"int":9},
		"skills":[
			{"id":"heal","name":"Luz sanadora","cd":3.0,"cost":20,"type":"heal_ally","amount":0.3},
			{"id":"sanctify","name":"Suelo sagrado","cd":20.0,"cost":40,"type":"zone_anti_undead","dps":15,"dur":8},
			{"id":"revive","name":"Plegaria de retorno","cd":120.0,"cost":80,"type":"revive_backpack"}]},
	"rogue": {"name":"Pícaro","hp":90,"mana":70,"speed":200,"stats":{"str":4,"dex":10,"int":4},
		"skills":[
			{"id":"backstab","name":"Puñalada trapera","cd":5.0,"cost":0,"type":"dash_crit","dmg":3.0},
			{"id":"smoke","name":"Bomba de humo","cd":15.0,"cost":10,"type":"aggro_drop","dur":4},
			{"id":"pickpocket","name":"Saqueo","cd":20.0,"cost":0,"type":"bonus_gold","mult":1.5}]},
}

func get_class_data(id: String) -> Dictionary: return CLASSES.get(id, CLASSES.warrior)

## XP necesaria para el siguiente nivel (curva suave).
func xp_for_level(lvl: int) -> int: return int(100 * pow(lvl, 1.55))
