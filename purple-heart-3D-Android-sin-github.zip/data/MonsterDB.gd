extends Node
## Base de datos de monstruos: 30 familias x 10 variantes = 300 monstruos únicos
## + 6 jefes de facción. Generados proceduralmente (ligero, sin 300 archivos).
## Rarezas: common, rare, epic, elite, legendary.

const FAMILIES := [
	# [id, nombre, hp_base, dmg_base, velocidad, bioma, comportamiento]
	["skeleton","Esqueleto",40,6,60,"castle","melee"],
	["zombie","Zombi",60,7,40,"swamp","melee"],
	["vampire","Vampiro",70,10,80,"castle","drain"],       # ahuyentado por ajo
	["bat","Murciélago",20,4,130,"castle","swarm"],
	["wraith","Espectro",50,9,90,"crypt","phase"],
	["ghoul","Necrófago",80,11,70,"crypt","melee"],
	["werewolf","Hombre lobo",110,14,110,"forest","charge"],
	["spider","Araña",35,6,100,"forest","poison"],
	["goblin","Goblin",30,5,95,"plains","swarm"],
	["orc","Orco",120,13,65,"plains","melee"],
	["troll","Troll",220,18,45,"mountain","smash"],
	["imp","Diablillo",28,7,105,"ashlands","ranged"],
	["harpy","Arpía",45,8,120,"mountain","dive"],
	["golem","Gólem",300,20,30,"mountain","smash"],
	["slime","Baba",55,4,50,"swamp","split"],
	["cultist","Cultista",45,12,60,"ruins","ranged"],
	["gargoyle","Gárgola",130,12,55,"castle","dive"],
	["banshee","Banshee",40,10,85,"crypt","scream"],
	["lich","Liche",90,16,50,"crypt","summon"],
	["demon","Demonio",160,19,75,"ashlands","charge"],
	["wyrm","Sierpe",180,15,70,"swamp","poison"],
	["mummy","Momia",100,10,45,"desert","melee"],
	["scorpion","Escorpión",60,9,85,"desert","poison"],
	["knight_fallen","Caballero caído",140,15,60,"ruins","melee"],
	["treant","Ent corrupto",260,17,35,"forest","smash"],
	["hound","Sabueso infernal",75,13,125,"ashlands","charge"],
	["witch","Bruja",55,14,60,"swamp","ranged"],
	["shade","Sombra",35,11,110,"crypt","phase"],
	["drake","Draco menor",200,21,80,"mountain","ranged"],
	["abomination","Abominación",350,24,40,"castle","smash"],
]

## Variantes: [sufijo, rareza, mult_hp, mult_dmg, mult_oro, mult_xp]
const VARIANTS := [
	["Común","common",1.0,1.0,1.0,1.0],
	["Joven","common",0.8,0.8,0.8,0.8],
	["Salvaje","common",1.1,1.1,1.1,1.1],
	["Rabioso","common",1.2,1.3,1.2,1.2],
	["Acorazado","rare",1.8,1.2,2.0,2.0],
	["Venenoso","rare",1.5,1.6,2.2,2.2],
	["Sangriento","epic",2.5,2.0,4.0,4.0],
	["Abismal","epic",3.0,2.2,4.5,4.5],
	["Élite Carmesí","elite",5.0,3.0,8.0,8.0],
	["Ancestral","legendary",10.0,4.5,20.0,20.0],
]

const RARITY_COLOR := {"common":"#ffffff","rare":"#4aa3ff","epic":"#b455ff","elite":"#ff5555","legendary":"#ffb800"}
const BOSSES := ["Reina Vampira Isolde","Rey Lich Maldrek","Señor Orco Gorrak","Dragón Ceniza Vyrnax","Arzobispo Cultista Sethra","Corazón Oscuro (Abominación Final)"]

var monsters: Dictionary = {}   # id -> Dictionary

func _ready() -> void:
	for fam in FAMILIES:
		for vi in VARIANTS.size():
			var v = VARIANTS[vi]
			var id := "%s_%d" % [fam[0], vi]
			monsters[id] = {
				"id": id, "name": "%s %s" % [fam[1], v[0]], "family": fam[0],
				"rarity": v[1], "hp": int(fam[2]*v[2]), "damage": int(fam[3]*v[3]),
				"speed": fam[4], "biome": fam[5], "behavior": fam[6],
				"gold": int(fam[2]*0.15*v[4]), "xp": int((fam[2]+fam[3]*3)*0.2*v[5]),
				"level": _tier(v[1]) * 5 + fam[2]/40,
				"color": RARITY_COLOR[v[1]],
				"weak_to_garlic": fam[0] in ["vampire","bat"],
			}
	for i in BOSSES.size():
		monsters["boss_%d" % i] = {"id":"boss_%d"%i,"name":BOSSES[i],"family":"boss","rarity":"legendary",
			"hp":3000+i*1500,"damage":40+i*12,"speed":50,"biome":"any","behavior":"boss",
			"gold":500+i*300,"xp":1500+i*800,"level":30+i*10,"color":"#ffb800","weak_to_garlic":false}
	print("Monstruos cargados: ", monsters.size())

func _tier(r: String) -> int:
	return {"common":0,"rare":1,"epic":2,"elite":3,"legendary":4}[r]

func get_by_biome_and_level(biome: String, lvl: int, spread := 8) -> Array:
	return monsters.values().filter(func(m): return (m.biome == biome or m.biome == "any") and abs(m.level - lvl) <= spread)

func roll_for_wave(wave: int) -> Dictionary:
	## Rareza ponderada: las oleadas altas mejoran las probabilidades de raros.
	var w := {"common":70.0,"rare":20.0+wave,"epic":6.0+wave*0.6,"elite":3.0+wave*0.3,"legendary":0.5+wave*0.1}
	var total := 0.0
	for k in w: total += w[k]
	var r := randf() * total
	var chosen := "common"
	for k in w:
		r -= w[k]
		if r <= 0: chosen = k; break
	var pool := monsters.values().filter(func(m): return m.rarity == chosen and m.family != "boss")
	return pool.pick_random()
