class_name Lore
extends RefCounted
## Lore del mundo y de sus guerras. Se muestra en el códice del juego.
const TITLE := "Las Guerras del Velo"

const ERAS := [
	{"name":"La Era Dorada","text":"Cuando los reinos de Aldoria, Vael y Karthun compartían las Tierras Claras, el Velo —una frontera invisible— separaba su mundo de la Dimensión Umbral. La Esmeralda Púrpura, tallada por los magos-reyes, anclaba ese Velo."},
	{"name":"La Primera Guerra: la Guerra de las Coronas","text":"Aldoria y Karthun pelearon por las minas de cristal. Los hechiceros de guerra desgarraron el Velo para convocar aliados oscuros. Así aparecieron los primeros vampiros y necrófagos."},
	{"name":"La Segunda Guerra: la Plaga Carmesí","text":"La Reina Isolde, última de la casa Vael, selló un pacto de sangre con las sombras. Su ejército de vampiros arrasó Vael. Los supervivientes huyeron a las ciudades fortificadas del exterior."},
	{"name":"La Tercera Guerra: el Cisma Orco","text":"Gorrak unió a orcos, trolls y goblins bajo el estandarte del hierro. La Liga de Ciudades los detuvo en el Paso Quebrado, pero a un precio devastador: la Liga se disolvió."},
	{"name":"La Caída","text":"El Rey Lich Maldrek, antiguo guardián del Velo, intentó robar la Esmeralda. El Castillo Umbral quedó atrapado entre dimensiones. Desde entonces, quien cae por una grieta despierta en sus muros."},
]

const SPIRIT_BACKSTORY := "El espíritu es Elowen, última archimaga de Aldoria. Su cuerpo murió defendiendo el Corazón; su voz permanece en las piedras del castillo."

const CITIES := {
	"Puerto Ceniza":"Ciudad portuaria de contrabandistas. Misiones de caza y escolta.",
	"Alto Vael":"Ruinas habitadas de la antigua Vael. Misiones contra vampiros.",
	"Karthun la Forja":"Ciudad enana de herreros. Misiones de recolección y mazmorras.",
	"Villa Brumosa":"Aldea de pantano, curanderas y brujas. Misiones de alquimia.",
	"Fortaleza del Paso":"Último bastión de la Liga. Misiones de defensa y jefes.",
}
