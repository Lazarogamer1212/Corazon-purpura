class_name Cabin
extends StaticBody2D
## Cabaña: punto de respawn + cofre. Los monstruos pueden destruirla (HP propia).
var owner_peer := 0
@onready var health: Health = $Health
func _ready() -> void:
	add_to_group("gates")   # atacable por monstruos
	health.max_hp = 250; health.hp = 250
	health.died.connect(func(_k): queue_free())
func pos_dist(p: Vector2) -> float: return global_position.distance_to(p)
func take_damage(n: int) -> void: health.apply_damage(n)
