class_name CabinBuilder
extends Node
## Construcción de cabañas FUERA del castillo (punto de respawn + almacén).
## El servidor valida: distancia al castillo, colisiones, recursos, límite por jugador.
const CASTLE_SAFE_RADIUS := 600.0        # no se puede construir dentro/junto al castillo
const MIN_DISTANCE_BETWEEN := 120.0
const MAX_CABINS_PER_PLAYER := 2
const COST := {"wood": 30, "stone": 15}
@export var cabin_scene: PackedScene

@rpc("any_peer", "call_local", "reliable")
func request_build(pos: Vector2) -> void:
	if not multiplayer.is_server(): return
	var peer := multiplayer.get_remote_sender_id()
	if peer == 0: peer = 1
	var player := _player_of(peer)
	if player == null: return
	var err := validate(peer, pos, player)
	if err != "": _deny.rpc_id(peer, err); return
	var mult := SkillTree.multiplier(Net.players.get(peer, {}), "build_cost_mult")
	for res in COST: player.get_node("Inventory").remove(res, int(COST[res] * mult))
	var cabin := cabin_scene.instantiate()
	cabin.global_position = pos
	cabin.set("owner_peer", peer)
	cabin.add_to_group("cabins")
	get_tree().current_scene.get_node("Buildings").add_child(cabin, true)

func validate(peer: int, pos: Vector2, player: Node) -> String:
	var heart := get_tree().get_first_node_in_group("castle_heart") as Node2D
	if heart and pos.distance_to(heart.global_position) < CASTLE_SAFE_RADIUS:
		return "Demasiado cerca del castillo."
	if player.global_position.distance_to(pos) > 200: return "Demasiado lejos."
	var mult := SkillTree.multiplier(Net.players.get(peer, {}), "build_cost_mult")
	for res in COST:
		if player.get_node("Inventory").count(res) < int(COST[res] * mult): return "Faltan recursos: %s." % res
	var mine := 0
	for c in get_tree().get_nodes_in_group("cabins"):
		if c.pos_dist(pos) < MIN_DISTANCE_BETWEEN: return "Hay otra construcción cerca."
		if c.owner_peer == peer: mine += 1
	if mine >= MAX_CABINS_PER_PLAYER: return "Límite de cabañas alcanzado."
	return ""

func _player_of(peer: int) -> Node:
	for p in get_tree().get_nodes_in_group("players"):
		if p.get_multiplayer_authority() == peer: return p
	return null

@rpc("authority", "reliable")
func _deny(msg: String) -> void: print("Construcción denegada: ", msg)
