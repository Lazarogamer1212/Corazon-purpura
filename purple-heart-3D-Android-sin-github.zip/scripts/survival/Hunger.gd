class_name Hunger
extends Node
## Barra de hambre. Baja con el tiempo (más rápido al correr/combatir). A 0: daño por inanición.
signal hunger_changed(value: float)
@export var max_hunger := 100.0
@export var decay_per_sec := 0.35
var value := 100.0
var health: Health
var _starve_tick := 0.0

func _process(delta: float) -> void:
	if not is_multiplayer_authority(): return
	value = maxf(0.0, value - decay_per_sec * delta)
	hunger_changed.emit(value)
	if value <= 0.0 and health:
		_starve_tick += delta
		if _starve_tick >= 2.0: _starve_tick = 0; health.apply_damage(3)
	# <25%: penalización de velocidad (lo lee PlayerController)

func eat(item: Dictionary) -> void:
	var mult := SkillTree.multiplier(Profile.data, "food_mult")
	value = minf(max_hunger, value + item.get("nutrition", 20) * mult)
	if health and item.has("heal"): health.heal(item.heal)

func speed_penalty() -> float:
	return 0.7 if value < 25.0 else 1.0
