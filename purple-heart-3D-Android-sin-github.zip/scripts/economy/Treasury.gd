extends Node
## Tesoro COMUNAL. Los monstruos sueltan oro al fondo común; cualquier jugador puede proponer
## una mejora y el servidor valida y descuenta. (Registrar como autoload "Treasury".)
signal changed(gold: int)
var gold := 0
var upgrades: Dictionary = {}   # id -> nivel actual

const CATALOG := {
	"hire_soldier":  {"name":"Contratar soldado real","cost":120,"max":20,"target":"gate","desc":"Protege una puerta; puede morir."},
	"gate_reinforced":{"name":"Puerta ultra resistente","cost":400,"max":3,"target":"gate","hp_mult":3.0},
	"wall_steel":    {"name":"Muros de acero","cost":600,"max":1,"target":"wall","from":"wood","to":"steel","hp_mult":4.0},
	"garlic_field":  {"name":"Sembrar ajo (anti-vampiros)","cost":80,"max":10,"target":"ground","effect":"repel_vampires","radius":160},
	"stake_turret":  {"name":"Torreta de estacas","cost":250,"max":10,"target":"ground","dps":25,"range":220},
	"heart_ward":    {"name":"Sello del Corazón (+vida)","cost":500,"max":5,"target":"heart","hp_bonus":300},
}

func add_gold(n: int) -> void:
	if not multiplayer.is_server(): return
	gold += n; _sync.rpc(gold)

@rpc("any_peer", "call_local", "reliable")
func request_purchase(upgrade_id: String, target_path: NodePath) -> void:
	if not multiplayer.is_server(): return
	var u: Dictionary = CATALOG.get(upgrade_id, {})
	if u.is_empty(): return
	var lvl: int = upgrades.get(upgrade_id, 0)
	if lvl >= u.max or gold < u.cost: return
	gold -= u.cost
	upgrades[upgrade_id] = lvl + 1
	_sync.rpc(gold)
	_apply.rpc(upgrade_id, target_path)

@rpc("authority", "call_local", "reliable")
func _sync(g: int) -> void:
	gold = g; changed.emit(g); EventBus.gold_changed.emit(g)

@rpc("authority", "call_local", "reliable")
func _apply(upgrade_id: String, target_path: NodePath) -> void:
	var t := get_node_or_null(target_path)
	if t and t.has_method("apply_upgrade"): t.apply_upgrade(upgrade_id, CATALOG[upgrade_id])
