class_name Soldier
extends CharacterBody2D
## Soldado real contratado con oro comunal. Defiende una puerta; puede morir.
@export var gate_path: NodePath
@export var damage := 14
@export var leash := 140.0
@onready var health: Health = $Health
var post: Vector2

func _ready() -> void:
	add_to_group("soldiers")
	post = global_position
	health.max_hp = 160; health.hp = 160; health.armor = 3
	health.died.connect(func(_k): queue_free())   # muere en combate; hay que recontratar

func _physics_process(_delta: float) -> void:
	if not multiplayer.is_server(): return
	var foe := _nearest_monster()
	var goal := post
	if foe and foe.global_position.distance_to(post) < leash:
		goal = foe.global_position
		if global_position.distance_to(foe.global_position) < 26 and randf() < 0.03:
			foe.get_node("Health").apply_damage(damage)
	velocity = (goal - global_position).limit_length(100) * 3.0
	move_and_slide()

func _nearest_monster() -> Node2D:
	var best: Node2D = null; var bd := 1e9
	for m in get_tree().get_nodes_in_group("monsters"):
		var d := global_position.distance_squared_to(m.global_position)
		if d < bd: bd = d; best = m
	return best
