class_name Monster
extends CharacterBody2D
## Monstruo genérico guiado por datos de MonsterDB. IA en el servidor; clientes solo ven posición.
var data: Dictionary
var heart_damage := 150
var target: Node2D
@onready var health: Health = $Health
const HEART_PATH := "castle_heart"

func setup(d: Dictionary, scale_mult: float) -> void:
	data = d
	name = "%s_%d" % [d.id, randi() % 99999]
	add_to_group("monsters")
	heart_damage = 100 + int(d.damage * 3)
	await ready
	health.max_hp = int(d.hp * scale_mult); health.hp = health.max_hp
	var spr := get_node_or_null("Sprite2D") as Sprite2D
	if spr: spr.texture = TextureLib.monster(d.family)
	modulate = Color(d.color) if d.rarity != "common" else Color.WHITE   # común = color original; raro+ = tinte de rareza
	if d.family == "boss": scale = Vector2.ONE * 2.5
	health.died.connect(_on_died)
	if d.rarity in ["elite", "legendary"]: scale = Vector2.ONE * 1.4

func _physics_process(_delta: float) -> void:
	if not multiplayer.is_server() or data.is_empty(): return
	target = _pick_target()
	if target == null: return
	var dir := (target.global_position - global_position).normalized()
	# Los vampiros huyen de campos de ajo
	if data.weak_to_garlic and _in_garlic(): dir = -dir
	velocity = dir * data.speed
	move_and_slide()
	var spr := get_node_or_null("Sprite2D") as Sprite2D
	if spr: spr.rotation = lerp_angle(spr.rotation, dir.angle(), 0.2)   # mira hacia donde camina
	if global_position.distance_to(target.global_position) < 28: _attack(target)

func _pick_target() -> Node2D:
	# Prioridad: soldado/puerta/jugador más cercano en 220px; si no, el Corazón.
	var best: Node2D = null; var best_d := 220.0
	for g in ["players", "soldiers", "gates"]:
		for n in get_tree().get_nodes_in_group(g):
			var d := global_position.distance_to(n.global_position)
			if d < best_d: best_d = d; best = n
	return best if best else get_tree().get_first_node_in_group("castle_heart")

var _atk_cd := 0.0
func _attack(t: Node) -> void:
	if _atk_cd > 0: _atk_cd -= get_physics_process_delta_time(); return
	_atk_cd = 1.0
	var h: Node = t.get_node_or_null("Health")
	if h: h.apply_damage(data.damage)
	elif t.has_method("take_damage"): t.take_damage(data.damage)

func _in_garlic() -> bool:
	for g in get_tree().get_nodes_in_group("garlic"):
		if global_position.distance_to(g.global_position) < g.get_meta("radius", 160): return true
	return false

func _on_died(killer_peer: int) -> void:
	Treasury.add_gold(data.gold)                                    # oro al fondo comunal
	EventBus.monster_killed.emit(killer_peer, data.id, data.rarity)
	ProgressionSystem.grant_xp(killer_peer, data.xp)
	queue_free()
