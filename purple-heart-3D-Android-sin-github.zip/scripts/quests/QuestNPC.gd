class_name QuestNPC
extends Area2D
## NPC dador de misiones (ciudades exteriores y dentro del castillo).
## La misión se genera según el nivel de QUIEN la acepta (adaptativa).
@export var npc_id := "npc_default"
var active: Dictionary = {}   # peer_id -> misión

@rpc("any_peer", "call_local", "reliable")
func request_quest(player_level: int) -> void:
	if not multiplayer.is_server(): return
	var peer := multiplayer.get_remote_sender_id()
	if peer == 0: peer = 1
	var rng := RandomNumberGenerator.new()
	rng.seed = hash("%d_%s_%d" % [GameState.run_seed, npc_id, Time.get_ticks_msec() / 60000])
	var q := QuestGenerator.generate(player_level, npc_id, rng)
	active[peer] = q
	_offer.rpc_id(peer, q)

@rpc("authority", "reliable")
func _offer(q: Dictionary) -> void:
	EventBus.quest_updated.emit(multiplayer.get_unique_id(), q.id)
	# UI muestra título/desc/recompensas y botón Aceptar
