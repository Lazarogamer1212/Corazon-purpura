class_name QuestGenerator
extends RefCounted
## Misiones adaptativas: dificultad, objetivos y recompensas escalan con el nivel
## del jugador que acepta. Generación server-side con la semilla de la partida.

enum Type { KILL, COLLECT, ESCORT, DUNGEON, DEFEND_GATE, DELIVER }

const BIOME_BY_LEVEL := [[1,"plains"],[6,"forest"],[10,"swamp"],[15,"crypt"],[20,"desert"],[25,"mountain"],[30,"ashlands"]]

static func generate(player_level: int, npc_id: String, rng: RandomNumberGenerator = null) -> Dictionary:
	rng = rng if rng else RandomNumberGenerator.new()
	var type: Type = rng.randi_range(0, 3) as Type
	var tier := int(player_level / 5)                         # 0,1,2...
	var biome := _biome_for(player_level)
	var pool := MonsterDB.get_by_biome_and_level(biome, player_level, 6 + tier)
	if pool.is_empty(): pool = MonsterDB.monsters.values().slice(0, 20)
	var target: Dictionary = pool.pick_random()
	var difficulty := 1.0 + tier * 0.25 + rng.randf_range(-0.1, 0.2)

	var q := {"id": "q_%d_%d" % [Time.get_ticks_msec(), rng.randi()], "npc": npc_id, "type": type,
		"level": player_level, "progress": 0, "done": false, "difficulty": difficulty}
	match type:
		Type.KILL:
			q.goal = clampi(int(5 + player_level * 0.8 * difficulty), 5, 60)
			q.target = target.family   # cuenta cualquier variante de la familia
			q.title = "Caza: %s" % target.name
			q.desc = "Elimina %d %s en %s." % [q.goal, target.name, biome]
		Type.COLLECT:
			q.goal = clampi(int(4 + player_level * 0.5), 4, 30)
			q.target = "item_" + biome
			q.title = "Recolecta recursos"
			q.desc = "Reúne %d materiales de %s." % [q.goal, biome]
		Type.ESCORT:
			q.goal = 1; q.target = "escort"
			q.title = "Escolta al mercader"
			q.desc = "Lleva al mercader a la ciudad sin que muera. Enemigos nivel ~%d." % player_level
		Type.DUNGEON:
			q.goal = 1; q.target = "dungeon_boss_%d" % clampi(tier, 0, 5)
			q.title = "Mazmorra: purga"
			q.desc = "Entra a la mazmorra y derrota a su guardián."
			difficulty *= 1.5
	# Recompensas escalan con el nivel y la dificultad
	q.reward_xp = int(ClassDB.xp_for_level(player_level) * 0.12 * difficulty)
	q.reward_gold = int((20 + player_level * 8) * difficulty)
	q.reward_item_tier = clampi(tier + (1 if type == Type.DUNGEON else 0), 0, 5)
	q.reward_skill_point = 1 if (type == Type.DUNGEON or rng.randf() < 0.15) else 0
	return q

static func _biome_for(lvl: int) -> String:
	var b := "plains"
	for e in BIOME_BY_LEVEL:
		if lvl >= e[0]: b = e[1]
	return b

## Llamado por EventBus.monster_killed (servidor).
static func on_monster_killed(quest: Dictionary, monster_id: String) -> bool:
	var fam: String = MonsterDB.monsters.get(monster_id, {}).get("family", "")
	if quest.done or quest.type != Type.KILL or quest.target != fam: return false
	quest.progress += 1
	quest.done = quest.progress >= quest.goal
	return quest.done
