extends Node2D
## Intro jugable: habitación -> temblor -> la tierra se abre -> caída -> despertar en el castillo.
## Escena IntroRoom.tscn: Player (skin del perfil), Camera2D, UI/Fade (ColorRect),
## Crack (Sprite2D invisible), UI/Dialog (Label).
enum S { FREE_ROAM, TREMOR, CRACK, FALL, WAKE }
var state := S.FREE_ROAM
@onready var cam: Camera2D = $Camera2D
@onready var fade: ColorRect = $UI/Fade
@onready var crack: Sprite2D = $Crack
@onready var player: CharacterBody2D = $Player

const SPIRIT_LINES := [
	"Despierta... ¿me oyes? No tienes mucho tiempo.",
	"Este es el Castillo Umbral. Caíste en él, igual que otros antes que tú.",
	"En su centro late la Esmeralda Púrpura. Es lo único que mantiene cerrada esta dimensión.",
	"Si las hordas la alcanzan, todo se pierde. Defiéndela. Juntos.",
]

func _ready() -> void:
	player.apply_skin(Profile.data.skin_id, Color(Profile.data.skin_color))
	await get_tree().create_timer(8.0).timeout   # ~8 s de exploración libre (joystick táctil)
	_tremor()

func _tremor() -> void:
	state = S.TREMOR
	var t := create_tween().set_loops(20)
	t.tween_callback(func(): cam.offset = Vector2(randf_range(-6, 6), randf_range(-6, 6)))
	t.tween_interval(0.05)
	await get_tree().create_timer(2.0).timeout
	t.kill(); cam.offset = Vector2.ZERO
	_open_ground()

func _open_ground() -> void:
	state = S.CRACK
	player.set_physics_process(false)
	crack.visible = true; crack.scale = Vector2.ZERO
	var t := create_tween()
	t.tween_property(crack, "scale", Vector2(6, 6), 1.2).set_trans(Tween.TRANS_EXPO)
	await t.finished
	state = S.FALL
	var f := create_tween().set_parallel()
	f.tween_property(player, "scale", Vector2(0.1, 0.1), 1.0)
	f.tween_property(player, "rotation", TAU * 2, 1.0)
	f.tween_property(fade, "color:a", 1.0, 1.0)
	await f.finished
	state = S.WAKE
	GameState.set_meta("intro_pending_spirit", true)
	Profile.data.has_seen_intro = true
	Profile.save()
	get_tree().change_scene_to_file("res://scenes/world/Castle.tscn")

## Castle.gd la llama al cargar si 'intro_pending_spirit' está activo.
static func play_spirit(label: Label, tree: SceneTree) -> void:
	for line in SPIRIT_LINES:
		label.text = line
		await tree.create_timer(3.5).timeout
	label.text = ""
