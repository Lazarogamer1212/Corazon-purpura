class_name DamageNumber
extends Label
## Número de daño flotante: sube, se desvanece. Críticos más grandes y amarillos; curas en verde.
static func spawn(target: Node, amount: int, crit := false) -> void:
	if not is_instance_valid(target) or not target is Node2D: return
	var l := DamageNumber.new()
	l.text = str(abs(amount))
	l.add_theme_font_size_override("font_size", 26 if crit else 16)
	l.add_theme_color_override("font_color", Color.LIME_GREEN if amount < 0 else (Color.GOLD if crit else Color.WHITE))
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 4)
	l.top_level = true
	l.global_position = target.global_position + Vector2(randf_range(-12, 12), -30)
	target.get_tree().current_scene.add_child(l)
	var t := l.create_tween().set_parallel()
	t.tween_property(l, "global_position:y", l.global_position.y - 40, 0.8)
	t.tween_property(l, "modulate:a", 0.0, 0.8).set_delay(0.3)
	t.chain().tween_callback(l.queue_free)
