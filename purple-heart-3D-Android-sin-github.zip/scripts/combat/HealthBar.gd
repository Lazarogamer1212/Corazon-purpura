class_name HealthBar
extends Node2D
## Barra de vida dibujada por código (sin texturas). Se oculta si está llena.
var ratio := 1.0
const W := 36.0
const H := 5.0

func update_bar(hp: int, max_hp: int) -> void:
	ratio = clampf(float(hp) / max_hp, 0.0, 1.0)
	visible = ratio < 1.0 or true   # cambia a 'ratio < 1.0' para ocultar con vida llena
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.7))
	var col := Color.LIME_GREEN if ratio > 0.5 else (Color.ORANGE if ratio > 0.25 else Color.RED)
	draw_rect(Rect2(1, 1, (W - 2) * ratio, H - 2), col)
