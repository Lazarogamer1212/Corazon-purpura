class_name Health
extends Node
## Componente de vida reutilizable (jugadores, monstruos, soldados, puertas, muros).
## Muestra barra de vida y números de daño flotantes en todos los clientes.
signal died(killer_peer: int)
signal changed(hp: int, max_hp: int)
@export var max_hp := 100
@export var armor := 0
@export var show_bar := true
var hp := 100
var _bar: HealthBar

func _ready() -> void:
	hp = max_hp
	if show_bar:
		_bar = HealthBar.new(); _bar.position = Vector2(-18, -34)
		get_parent().add_child.call_deferred(_bar)
		_bar.update_bar.call_deferred(hp, max_hp)

## Siempre llamar SOLO desde el servidor.
func apply_damage(amount: int, killer_peer := 0, crit := false) -> void:
	if not multiplayer.is_server() or hp <= 0: return
	var dmg := maxi(1, amount - armor)
	hp = maxi(0, hp - dmg)
	_replicate.rpc(hp, dmg, crit)
	if hp == 0:
		died.emit(killer_peer)
		EventBus.entity_died.emit(get_parent().get_path(), killer_peer)

func heal(amount: int) -> void:
	if multiplayer.is_server():
		hp = mini(max_hp, hp + amount); _replicate.rpc(hp, -amount, false)

@rpc("authority", "call_local", "reliable")
func _replicate(new_hp: int, dmg: int, crit: bool) -> void:
	hp = new_hp
	changed.emit(hp, max_hp)
	if _bar: _bar.update_bar(hp, max_hp)
	DamageNumber.spawn(get_parent(), dmg, crit)
