extends Control
## Pantalla de creación de perfil: nombre + skin + color + clase.
## Nodos esperados (ProfileCreation.tscn): LineEdit "Name", ItemList "Skins",
## ColorPickerButton "Tint", OptionButton "Class", TextureRect "Preview", Button "Confirm".
@onready var name_edit: LineEdit = $Name
@onready var skins: ItemList = $Skins
@onready var tint: ColorPickerButton = $Tint
@onready var class_opt: OptionButton = $Class
@onready var preview: TextureRect = $Preview

const SKIN_COUNT := 8   # assets/skins/skin_0.png ... skin_7.png

func _ready() -> void:
	for i in SKIN_COUNT:
		skins.add_icon_item(TextureLib.skin(i))
	for id in ClassDB.CLASSES:
		class_opt.add_item(ClassDB.CLASSES[id].name)
		class_opt.set_item_metadata(class_opt.item_count - 1, id)
	skins.item_selected.connect(func(_i): _refresh())
	tint.color_changed.connect(func(_c): _refresh())
	$Confirm.pressed.connect(_confirm)
	skins.select(0); _refresh()

func _refresh() -> void:
	var sel := skins.get_selected_items()
	preview.texture = skins.get_item_icon(sel[0]) if sel.size() > 0 else null
	preview.modulate = tint.color

func _confirm() -> void:
	if name_edit.text.strip_edges().length() < 2: return
	var sel := skins.get_selected_items()
	Profile.create(name_edit.text, sel[0] if sel.size() > 0 else 0, tint.color,
		class_opt.get_item_metadata(class_opt.selected))
	get_tree().change_scene_to_file("res://scenes/ui/Lobby.tscn")
