class_name Dungeon
extends Node2D
## Mazmorra instanciada: cada grupo que entra obtiene su propia copia (sub-escena),
## con salas generadas por semilla, monstruos del nivel medio del grupo y cofre final.
@export var entrance_level := 10
var party: Array[int] = []

func enter(peers: Array[int]) -> void:
	party = peers
	var avg := 0
	for p in peers: avg += Net.players.get(p, {"level": 1}).level
	avg = avg / maxi(peers.size(), 1)
	var rng := RandomNumberGenerator.new(); rng.seed = GameState.run_seed + entrance_level
	for room in range(4 + avg / 10):
		for i in rng.randi_range(4, 8):
			var pool := MonsterDB.get_by_biome_and_level("crypt", avg, 6)
			# ... instanciar Monster.tscn con pool.pick_random() en cada sala
	# Sala final: jefe + cofre con loot de tier alto (equipo "alto nivel")
	# loot_tier = clamp(avg/5 + 1, 1, 6)
