class_name Mount
extends Node
## Lógica de montura. Se adjunta al jugador. Todo gateado por SkillTree.
var rider_profile: Dictionary
var mounted := false
var horse_armor := 0          # defensa extra de la barda
var horse_hp := 120

func toggle_mount() -> bool:
	if not SkillTree.has(rider_profile, "can_mount"): return false
	mounted = not mounted
	return true

func speed_multiplier() -> float:
	return SkillTree.multiplier(rider_profile, "mount_speed") if mounted else 1.0

func can_attack() -> bool:
	return not mounted or SkillTree.has(rider_profile, "mounted_attack")

func equip_barding(defense: int) -> bool:
	if not SkillTree.has(rider_profile, "horse_armor_slot"): return false
	horse_armor = defense; return true

## El caballo recibe parte del daño mientras se está montado.
func absorb_damage(amount: int) -> int:
	if not mounted: return amount
	var reduced := max(1, amount - horse_armor)
	horse_hp -= int(reduced * 0.5)
	if horse_hp <= 0: mounted = false   # el caballo cae; el jugador se desmonta
	return int(reduced * 0.5)
