class_name SkillTree
extends Node
## Árbol de habilidades pasivas. Incluye la rama del CABALLO (requiere INT).
## Cada nodo: requires (prereqs), min_level, int_req, cost (puntos).
## El servidor valida todo; el cliente solo pide 'request_unlock'.

const NODES := {
	# ---------- RAMA CABALLO ----------
	"horse_1_rider":      {"name":"Jinete","desc":"Permite montar a caballo (+80% velocidad).","requires":[],"min_level":3,"int_req":3,"cost":1,"branch":"horse"},
	"horse_2_mounted":    {"name":"Combate montado","desc":"Ataque cuerpo a cuerpo y a distancia montado.","requires":["horse_1_rider"],"min_level":8,"int_req":6,"cost":2,"branch":"horse"},
	"horse_3_barding":    {"name":"Barda","desc":"Equipar armadura al caballo.","requires":["horse_2_mounted"],"min_level":14,"int_req":9,"cost":3,"branch":"horse"},
	"horse_4_charge":     {"name":"Carga de caballería","desc":"Embestida: daño y derribo en línea.","requires":["horse_3_barding"],"min_level":20,"int_req":12,"cost":4,"branch":"horse"},
	"horse_5_steed":      {"name":"Corcel espectral","desc":"Invocar caballo gratis; atraviesa pantanos.","requires":["horse_4_charge"],"min_level":28,"int_req":16,"cost":5,"branch":"horse"},
	# ---------- PASIVAS GENERALES ----------
	"gen_toughness":      {"name":"Piel dura","desc":"+10% vida máxima.","requires":[],"min_level":2,"int_req":0,"cost":1,"branch":"general"},
	"gen_scavenger":      {"name":"Carroñero","desc":"+15% oro de monstruos.","requires":[],"min_level":5,"int_req":0,"cost":2,"branch":"general"},
	"gen_forager":        {"name":"Recolector","desc":"La comida restaura +25% hambre.","requires":[],"min_level":4,"int_req":0,"cost":1,"branch":"general"},
	"gen_builder":        {"name":"Constructor","desc":"Cabañas -30% de coste.","requires":["gen_scavenger"],"min_level":10,"int_req":4,"cost":2,"branch":"general"},
}

## Bonos numéricos de cada nodo (aplicados por PlayerStats).
const EFFECTS := {
	"horse_1_rider":{"can_mount":true,"mount_speed":1.8},
	"horse_2_mounted":{"mounted_attack":true},
	"horse_3_barding":{"horse_armor_slot":true},
	"horse_4_charge":{"horse_charge":true},
	"horse_5_steed":{"free_horse":true},
	"gen_toughness":{"hp_mult":1.1},
	"gen_scavenger":{"gold_mult":1.15},
	"gen_forager":{"food_mult":1.25},
	"gen_builder":{"build_cost_mult":0.7},
}

static func can_unlock(skill_id: String, profile: Dictionary) -> Dictionary:
	if not NODES.has(skill_id): return {"ok":false,"reason":"Habilidad desconocida"}
	var n: Dictionary = NODES[skill_id]
	if skill_id in profile.unlocked_skills: return {"ok":false,"reason":"Ya desbloqueada"}
	for r in n.requires:
		if r not in profile.unlocked_skills: return {"ok":false,"reason":"Falta: %s" % NODES[r].name}
	if profile.level < n.min_level: return {"ok":false,"reason":"Nivel %d requerido" % n.min_level}
	if profile.int_stat < n.int_req: return {"ok":false,"reason":"Inteligencia %d requerida" % n.int_req}
	if profile.skill_points < n.cost: return {"ok":false,"reason":"Puntos insuficientes"}
	return {"ok":true,"reason":""}

static func has(profile: Dictionary, effect: String) -> bool:
	for id in profile.unlocked_skills:
		if EFFECTS.get(id, {}).has(effect): return true
	return false

static func multiplier(profile: Dictionary, effect: String) -> float:
	var m := 1.0
	for id in profile.unlocked_skills:
		m *= EFFECTS.get(id, {}).get(effect, 1.0)
	return m

# ---------- Red ----------
@rpc("any_peer", "reliable")
func request_unlock(skill_id: String) -> void:
	if not multiplayer.is_server(): return
	var peer := multiplayer.get_remote_sender_id()
	var prof: Dictionary = GameState.get_meta("profiles", {}).get(peer, Profile.data)  # servidor guarda perfiles
	var chk := can_unlock(skill_id, prof)
	if not chk.ok:
		_deny.rpc_id(peer, chk.reason); return
	prof.skill_points -= NODES[skill_id].cost
	prof.unlocked_skills.append(skill_id)
	_confirm.rpc_id(peer, skill_id, prof.skill_points)
	EventBus.skill_unlocked.emit(peer, skill_id)

@rpc("authority", "reliable")
func _confirm(skill_id: String, points_left: int) -> void:
	Profile.data.unlocked_skills.append(skill_id)
	Profile.data.skill_points = points_left
	Profile.save()
	EventBus.skill_unlocked.emit(multiplayer.get_unique_id(), skill_id)

@rpc("authority", "reliable")
func _deny(reason: String) -> void: print("Desbloqueo denegado: ", reason)
