class_name Gate
extends StaticBody2D
## Puerta / muro con mejoras. Se registra en 'gates' para que los monstruos la ataquen.
@export var is_wall := false
@export var soldier_scene: PackedScene
var material := "wood"
@onready var health: Health = $Health

func _ready() -> void:
	add_to_group("walls" if is_wall else "gates")
	health.max_hp = 200 if not is_wall else 150; health.hp = health.max_hp

func apply_upgrade(id: String, u: Dictionary) -> void:
	match id:
		"gate_reinforced", "wall_steel":
			health.max_hp = int(health.max_hp * u.hp_mult); health.hp = health.max_hp
			if u.has("to"): material = u.to; modulate = Color(0.7, 0.75, 0.85)
		"hire_soldier":
			if multiplayer.is_server() and soldier_scene:
				var s := soldier_scene.instantiate()
				s.global_position = global_position + Vector2(randf_range(-30, 30), 40)
				get_parent().add_child(s, true)

func take_damage(n: int) -> void: health.apply_damage(n)
