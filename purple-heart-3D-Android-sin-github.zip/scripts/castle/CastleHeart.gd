class_name CastleHeart
extends StaticBody2D
## La Esmeralda Púrpura. Si su vida llega a 0 (o un monstruo la toca): GAME OVER y se pierde todo.
@export var max_hp := 1000
var hp := 1000
var _regen_timer := 0.0

func _ready() -> void:
	add_to_group("castle_heart")
	hp = max_hp
	if has_node("Sprite2D"): $Sprite2D.texture = TextureLib.object("castle_heart")
	Lighting.attach_heart_glow(self)
	var area := Area2D.new(); var shape := CollisionShape2D.new()
	var c := CircleShape2D.new(); c.radius = 40; shape.shape = c
	area.add_child(shape); add_child(area)
	area.body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if not multiplayer.is_server(): return
	if body.is_in_group("monsters"):
		# Regla del lore: una oleada que LLEGA al corazón lo daña masivamente.
		take_damage(body.get("heart_damage") if body.get("heart_damage") else 150)
		body.queue_free()

func take_damage(amount: int) -> void:
	if not multiplayer.is_server(): return
	hp = max(0, hp - amount)
	_sync.rpc(hp)
	if hp <= 0: GameState.trigger_game_over("El Corazón del Castillo ha caído.")

func heal(amount: int) -> void:
	if multiplayer.is_server():
		hp = min(max_hp, hp + amount); _sync.rpc(hp)

func _process(delta: float) -> void:
	if not multiplayer.is_server() or hp >= max_hp: return
	_regen_timer += delta
	if _regen_timer > 5.0: _regen_timer = 0; heal(2)   # regen lenta entre oleadas

@rpc("authority", "call_local", "reliable")
func _sync(new_hp: int) -> void:
	hp = new_hp
	EventBus.heart_hp_changed.emit(hp, max_hp)
	if has_node("Glow"): $Glow.color = Color(0.62, 0.30, 1.0).lerp(Color(1, 0.2, 0.2), 1.0 - float(hp) / max_hp)   # se enrojece al peligrar
