class_name WaveManager
extends Node
## Oleadas de monstruos. Escala con nº de oleada y nº de jugadores. Solo el servidor spawnea.
@export var spawn_points: Array[NodePath]
@export var monster_scene: PackedScene          # escena genérica Monster.tscn
@export var time_between_waves := 45.0
var wave := 0
var alive := 0
var _active := false

func _ready() -> void:
	EventBus.entity_died.connect(_on_died)
	if multiplayer.is_server(): _countdown()

func _countdown() -> void:
	await get_tree().create_timer(time_between_waves).timeout
	if GameState.phase == GameState.Phase.PLAYING: _start_wave()
	else: _countdown()

func _start_wave() -> void:
	wave += 1
	var players := maxi(Net.players.size(), 1)
	var is_boss := wave % 10 == 0
	var count := int((6 + wave * 2.5) * (0.6 + players * 0.15))
	EventBus.wave_started.emit(wave, is_boss)
	_announce.rpc(wave, is_boss)
	_active = true
	if is_boss: _spawn(MonsterDB.monsters["boss_%d" % mini((wave / 10) - 1, 5)])
	for i in count:
		_spawn(MonsterDB.roll_for_wave(wave))
		await get_tree().create_timer(0.4).timeout

func _spawn(data: Dictionary) -> void:
	var m := monster_scene.instantiate()
	m.setup(data, 1.0 + wave * 0.04)         # escala suave de stats por oleada
	var sp: Marker2D = get_node(spawn_points.pick_random())
	m.global_position = sp.global_position + Vector2(randf_range(-30, 30), randf_range(-30, 30))
	get_parent().get_node("Monsters").add_child(m, true)   # MultiplayerSpawner replica
	alive += 1

func _on_died(path: NodePath, _killer: int) -> void:
	var n := get_node_or_null(path)
	if n and n.is_in_group("monsters"):
		alive -= 1
		if alive <= 0 and _active:
			_active = false
			_wave_cleared()

func _wave_cleared() -> void:
	# Bonificación comunal por limpiar la oleada
	Treasury.add_gold(25 + wave * 10)
	_countdown()

@rpc("authority", "call_local", "reliable")
func _announce(n: int, boss: bool) -> void:
	EventBus.wave_started.emit(n, boss)
