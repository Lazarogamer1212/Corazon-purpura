extends Node3D
## Corazón Púrpura 3D — mundo procedural optimizado para Android.
## Vegetación con shader de viento, sombras dinámicas, fauna, luciérnagas,
## mariposas, antorchas, ciclo día/noche, IA de criaturas y barra de habilidades móvil.

const WORLD_SIZE=260.0
const TREE_COUNT=115
const ANIMAL_COUNT=28
const ENEMY_COUNT=14
var player:Player3D
var camera:Camera3D
var ui:CanvasLayer
var joystick:Control
var creatures=[]
var torches=[]
var time_of_day=0.0
var day_length=420.0
var rng=RandomNumberGenerator.new()
var wind_time=0.0
var health_bar:ProgressBar
var mana_bar:ProgressBar
var status_label:Label
var ability_buttons=[]

func _ready():
    rng.seed=726381
    _setup_environment()
    _build_world()
    _spawn_player()
    _setup_camera()
    _build_ui()
    _spawn_fauna()
    _spawn_enemies()
    _spawn_fireflies()
    _spawn_butterflies()
    _spawn_torches()
    _build_castle()
    _build_village()

func mat(c:Color, rough=0.75, metallic=0.0):
    var m=StandardMaterial3D.new(); m.albedo_color=c; m.roughness=rough; m.metallic=metallic
    return m

func mesh_node(mesh:PrimitiveMesh,pos:Vector3,m:Material,parent:Node3D=self):
    var n=MeshInstance3D.new(); n.mesh=mesh; n.position=pos; n.material_override=m; parent.add_child(n); return n

func box(size:Vector3,pos:Vector3,m:Material,parent:Node3D=self):
    var b=BoxMesh.new(); b.size=size; return mesh_node(b,pos,m,parent)

func cylinder(radius:float,height:float,pos:Vector3,m:Material,parent:Node3D=self):
    var c=CylinderMesh.new(); c.top_radius=radius; c.bottom_radius=radius*1.08; c.height=height
    return mesh_node(c,pos,m,parent)

func _setup_environment():
    var env=WorldEnvironment.new()
    var e=Environment.new()
    e.background_mode=Environment.BG_COLOR
    e.background_color=Color("#0b1220")
    e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color=Color("#9da9c9"); e.ambient_light_energy=0.72
    e.tonemap_mode=Environment.TONE_MAPPER_FILMIC
    e.glow_enabled=true; e.glow_intensity=1.0
    e.fog_enabled=true; e.fog_light_color=Color("#27344b"); e.fog_light_energy=.35
    e.fog_density=.0045
    env.environment=e; add_child(env)
    var sun=DirectionalLight3D.new()
    sun.name="Sun"; sun.rotation_degrees=Vector3(-52,-35,0)
    sun.light_energy=1.25; sun.light_color=Color("#fff2d0")
    sun.shadow_enabled=true; sun.directional_shadow_max_distance=180
    sun.directional_shadow_split_1=0.08; sun.directional_shadow_split_2=.25; sun.directional_shadow_split_3=.6
    add_child(sun)

func _build_world():
    var ground_mat=mat(Color("#314f32"),.95)
    var ground=BoxMesh.new(); ground.size=Vector3(WORLD_SIZE,1,WORLD_SIZE)
    var g=mesh_node(ground,Vector3(0,-.55,0),ground_mat)
    var body=StaticBody3D.new(); body.position=Vector3(0,-.55,0); add_child(body)
    var cs=CollisionShape3D.new(); var shape=BoxShape3D.new(); shape.size=Vector3(WORLD_SIZE,1,WORLD_SIZE); cs.shape=shape; body.add_child(cs)
    _build_paths()
    for i in TREE_COUNT:
        var x=rng.randf_range(-WORLD_SIZE/2+8,WORLD_SIZE/2-8)
        var z=rng.randf_range(-WORLD_SIZE/2+8,WORLD_SIZE/2-8)
        if Vector2(x,z).length()<34: continue
        _make_tree(Vector3(x,0,z),rng.randf_range(.8,1.45))
    _spawn_grass()
    _build_water()
    _build_ruins()

func _build_paths():
    var stone=mat(Color("#777b84"),.9)
    for z in range(-110,111,6): box(Vector3(4,.06,5),Vector3(0,.02,z),stone)
    for x in range(-110,111,6): box(Vector3(5,.06,4),Vector3(x,.025,0),stone)

func _build_water():
    var water=mat(Color("#174e69"),.18,.15)
    var plane=BoxMesh.new(); plane.size=Vector3(48,.12,72)
    var w=mesh_node(plane,Vector3(82,-.02,65),water)
    var body=StaticBody3D.new(); body.position=Vector3(82,-.5,65); add_child(body)
    var cs=CollisionShape3D.new(); var sh=BoxShape3D.new(); sh.size=Vector3(48,1,72); cs.shape=sh; body.add_child(cs)

func _make_tree(p:Vector3,s:float):
    var n=Node3D.new(); n.position=p; n.scale=Vector3.ONE*s; add_child(n)
    var trunk=mat(Color("#4a2d22"),.9)
    cylinder(.34,3.2,Vector3(0,1.6,0),trunk,n)
    var leaf=mat(Color("#1e5b39"),.82)
    for j in 3:
        var crown=SphereMesh.new(); crown.radius=1.55; crown.height=2.8
        var c=mesh_node(crown,Vector3((j-1)*.65,3.1+j*.35,0),leaf,n)
        c.scale=Vector3(1.1,.9,1.1)
        _add_wind(c,j*.7)
    var shadow=OmniLight3D.new()
    # no light on trees; retained node is avoided for performance

func _add_wind(node:Node3D,phase:float):
    node.set_meta("wind_phase",phase)
    node.add_to_group("wind")

func _spawn_grass():
    var gm=ShaderMaterial.new()
    var sh=Shader.new()
    sh.code="""shader_type spatial;
render_mode cull_disabled,shadows_disabled;
uniform vec4 grass_color : source_color = vec4(0.16,0.42,0.18,1.0);
uniform float wind_strength=0.16;
void vertex(){
    float sway=sin(TIME*2.4 + VERTEX.x*3.0 + VERTEX.z*1.7)*wind_strength;
    VERTEX.x += sway * UV.y;
    VERTEX.z += cos(TIME*1.9 + VERTEX.x*2.0)*0.06*UV.y;
}
void fragment(){ ALBEDO=grass_color.rgb; ROUGHNESS=.95; }
"""
    gm.shader=sh
    for i in 120:
        var n=MeshInstance3D.new(); var q=QuadMesh.new(); q.size=Vector2(.65,.9); n.mesh=q
        n.material_override=gm; n.position=Vector3(rng.randf_range(-120,120),.45,rng.randf_range(-120,120))
        if Vector2(n.position.x,n.position.z).length()<32: continue
        n.rotation.y=rng.randf_range(0,TAU); n.scale=Vector3.ONE*rng.randf_range(.7,1.5)
        add_child(n)

func _build_castle():
    var root=Node3D.new(); root.name="PurpleCastle"; root.position=Vector3(0,0,-68); add_child(root)
    var stone=mat(Color("#4e5368"),.72,.25); var purple=mat(Color("#5f35a5"),.45,.2)
    box(Vector3(42,7,3),Vector3(0,3.5,15),stone,root)
    box(Vector3(42,7,3),Vector3(0,3.5,-15),stone,root)
    box(Vector3(3,7,33),Vector3(-19.5,3.5,0),stone,root)
    box(Vector3(3,7,33),Vector3(19.5,3.5,0),stone,root)
    cylinder(2.5,2.0,Vector3(0,5.7,0),purple,root)
    var heart=OmniLight3D.new(); heart.light_color=Color("#b04cff"); heart.light_energy=8; heart.omni_range=18; heart.position=Vector3(0,4.5,0); root.add_child(heart)
    var tw=heart.create_tween().set_loops(); tw.tween_property(heart,"light_energy",12.0,.8); tw.tween_property(heart,"light_energy",5.0,.8)
    for x in [-19.5,19.5]:
        for z in [-13,13]:
            cylinder(2.1,10,Vector3(x,5,z),stone,root)
    _make_banner(root,Vector3(0,7,0))

func _make_banner(parent,pos):
    var banner=BoxMesh.new(); banner.size=Vector3(5,.1,3)
    var b=mesh_node(banner,pos,mat(Color("#6d2bc4"),.6),parent); b.rotation.x=.05

func _build_village():
    var wood=mat(Color("#70452c"),.92); var roof=mat(Color("#352338"),.78)
    for p in [Vector3(-42,0,-12),Vector3(-52,0,8),Vector3(-37,0,20),Vector3(42,0,-8),Vector3(52,0,13)]:
        var h=box(Vector3(8,4,7),p+Vector3(0,2,0),wood)
        var r=mesh_node(CylinderMesh.new(),p+Vector3(0,5,0),roof)
        r.scale=Vector3(3.8,1.2,3.8)

func _build_ruins():
    var stone=mat(Color("#45495a"),.9)
    for i in 16:
        var p=Vector3(rng.randf_range(-105,105),0,rng.randf_range(-105,105))
        if abs(p.x)<55 and abs(p.z)<55: continue
        box(Vector3(rng.randf_range(1,4),rng.randf_range(1,5),rng.randf_range(1,4)),p+Vector3(0,1,0),stone)

func _spawn_player():
    player=preload("res://scripts/3d/Player3D.gd").new()
    player.name="Hero"; player.position=Vector3(0,1,12); add_child(player)
    player.ability_used.connect(_on_ability)
    player.health_changed.connect(_on_health)

func _setup_camera():
    camera=Camera3D.new(); camera.position=Vector3(0,10,14); camera.rotation_degrees=Vector3(-31,0,0)
    add_child(camera); camera.current=true

func _process(delta):
    wind_time+=delta
    time_of_day=fmod(time_of_day+delta,day_length)
    var phase=time_of_day/day_length
    var sun=get_node_or_null("Sun") as DirectionalLight3D
    if sun:
        sun.rotation_degrees.x=lerp(-20.0,-145.0,phase)
        sun.light_energy=lerp(.25,1.25,clamp(sin(phase*TAU)*.5+.5,0.0,1.0))
    if player and camera:
        var desired=player.global_position+Vector3(0,9,12)
        camera.global_position=camera.global_position.lerp(desired,delta*5)
        camera.look_at(player.global_position+Vector3(0,1,0),Vector3.UP)
    _animate_world(delta)
    _update_ai(delta)

func _animate_world(delta):
    for n in get_tree().get_nodes_in_group("wind"):
        var phase=float(n.get_meta("wind_phase",0.0))
        n.rotation.z=sin(wind_time*1.8+phase)*.035
    for t in torches:
        var tl=t.get_meta("light") as OmniLight3D
        if tl:
            tl.light_energy=2.6+sin(wind_time*17.0+float(t.position.x))*.65
            tl.omni_range=9.0+sin(wind_time*11.0)*.7
    for f in get_tree().get_nodes_in_group("firefly"):
        f.position.y=1.5+sin(wind_time*1.7+f.get_meta("phase",0.0))*.65
        f.position.x+=sin(wind_time*.9+f.get_meta("phase",0.0))*delta*.35
        f.position.z+=cos(wind_time*1.1+f.get_meta("phase",0.0))*delta*.25
    for b in get_tree().get_nodes_in_group("butterfly"):
        b.position.y=2.1+sin(wind_time*3+b.get_meta("phase",0))*0.6
        b.position.x+=sin(wind_time*1.2+b.get_meta("phase",0))*delta*1.5
        b.position.z+=cos(wind_time*1.1+b.get_meta("phase",0))*delta*1.2

func _spawn_fauna():
    for i in ANIMAL_COUNT:
        var a=_make_creature(false)
        a.position=Vector3(rng.randf_range(-100,100),.55,rng.randf_range(-100,100))
        creatures.append(a)

func _spawn_enemies():
    for i in ENEMY_COUNT:
        var a=_make_creature(true)
        a.position=Vector3(rng.randf_range(-105,105),.8,rng.randf_range(-105,105))
        creatures.append(a)

func _make_creature(enemy:bool):
    var n=Node3D.new(); n.set_meta("enemy",enemy); n.set_meta("phase",rng.randf_range(0,6.28)); n.set_meta("speed",rng.randf_range(1.0,2.5) if not enemy else rng.randf_range(2.0,3.6))
    var body=CapsuleMesh.new(); body.radius=.35 if not enemy else .5; body.height=.75 if not enemy else 1.15
    mesh_node(body,Vector3(0,.65,0),mat(Color("#9a6b45") if not enemy else Color("#6f273d"),.8),n)
    var head=SphereMesh.new(); head.radius=.38; head.height=.76
    mesh_node(head,Vector3(0,1.35,0),mat(Color("#c98c58") if not enemy else Color("#8b304d"),.78),n)
    add_child(n); return n

func _update_ai(delta):
    for n in creatures:
        if not is_instance_valid(n): continue
        var enemy=bool(n.get_meta("enemy",false))
        var sp=float(n.get_meta("speed",2.0))
        var dir=Vector3.ZERO
        if enemy and player:
            dir=(player.global_position-n.global_position); dir.y=0; dir=dir.normalized()
            if n.global_position.distance_to(player.global_position)<3.0 and rng.randf()<delta*.8: player.take_damage(5)
        else:
            var ph=float(n.get_meta("phase",0.0))
            dir=Vector3(sin(wind_time*.35+ph),0,cos(wind_time*.29+ph)).normalized()
        n.position+=dir*sp*delta
        n.position.y=(.55 if not enemy else .8) + sin(wind_time*5.0+float(n.get_meta("phase",0.0)))*.035
        if dir.length()>0.1: n.rotation.y=lerp_angle(n.rotation.y,atan2(-dir.x,-dir.z),delta*4)

func _spawn_fireflies():
    var glow=mat(Color("#b8ff72"),.2,0.0)
    for i in 42:
        var s=SphereMesh.new(); s.radius=.045; s.height=.09
        var f=mesh_node(s,Vector3(rng.randf_range(-100,100),rng.randf_range(1.0,4.0),rng.randf_range(-100,100)),glow)
        f.add_to_group("firefly"); f.set_meta("phase",rng.randf_range(0,6.28))
        var l=OmniLight3D.new(); l.light_color=Color("#9dff66"); l.light_energy=.35; l.omni_range=2.0; f.add_child(l)

func _spawn_butterflies():
    var wing=mat(Color("#d7a4ff"),.3)
    for i in 14:
        var b=Node3D.new(); b.position=Vector3(rng.randf_range(-90,90),2,rng.randf_range(-90,90)); add_child(b); b.add_to_group("butterfly"); b.set_meta("phase",rng.randf_range(0,6.28))
        for x in [-1,1]:
            var q=BoxMesh.new(); q.size=Vector3(.18,.03,.55)
            var w=mesh_node(q,Vector3(x*.16,0,0),wing,b); w.rotation.y=x*.25

func _spawn_torches():
    for p in [Vector3(-20,4,-53),Vector3(20,4,-53),Vector3(-20,4,-83),Vector3(20,4,-83),Vector3(-42,2,-12),Vector3(42,2,-8)]:
        var t=Node3D.new(); t.position=p; add_child(t)
        cylinder(.09,1.8,Vector3(0,-.9,0),mat(Color("#30201b"),.9),t)
        var flame=SphereMesh.new(); flame.radius=.22; flame.height=.44
        mesh_node(flame,Vector3(0,.2,0),mat(Color("#ff8a28"),.25),t)
        var l=OmniLight3D.new(); l.light_color=Color("#ff7b2e"); l.light_energy=3.2; l.omni_range=10; l.shadow_enabled=true; t.add_child(l)
        t.set_meta("light",l); torches.append(t)

func _build_ui():
    ui=CanvasLayer.new(); add_child(ui)
    var top=ColorRect.new(); top.color=Color(0.035,0.025,0.075,.92); top.position=Vector2(18,16); top.size=Vector2(360,86); ui.add_child(top)
    var title=Label.new(); title.text="CORAZÓN PÚRPURA  •  REINOS"; title.position=Vector2(28,22); title.add_theme_font_size_override("font_size",18); ui.add_child(title)
    health_bar=_bar(Color("#d94358")); health_bar.position=Vector2(28,52); health_bar.size=Vector2(330,16); ui.add_child(health_bar)
    mana_bar=_bar(Color("#704cff")); mana_bar.position=Vector2(28,72); mana_bar.size=Vector2(330,10); ui.add_child(mana_bar)
    status_label=Label.new(); status_label.text="Bosque de Umbral  •  Día"; status_label.position=Vector2(20,112); status_label.add_theme_font_size_override("font_size",15); ui.add_child(status_label)
    _build_ability_bar()
    _build_joystick()

func _bar(c:Color):
    var b=ProgressBar.new(); b.show_percentage=false; var bg=StyleBoxFlat.new(); bg.bg_color=Color("#171827"); bg.corner_radius_top_left=7; bg.corner_radius_top_right=7; bg.corner_radius_bottom_left=7; bg.corner_radius_bottom_right=7
    var fg=StyleBoxFlat.new(); fg.bg_color=c; fg.corner_radius_top_left=7; fg.corner_radius_top_right=7; fg.corner_radius_bottom_left=7; fg.corner_radius_bottom_right=7
    b.add_theme_stylebox_override("background",bg); b.add_theme_stylebox_override("fill",fg); b.max_value=100; b.value=100; return b

func _build_ability_bar():
    var bar=HBoxContainer.new(); bar.position=Vector2(430,615); bar.size=Vector2(420,90); bar.add_theme_constant_override("separation",8); ui.add_child(bar)
    var names=["⚔","✦","❄","☄","♜","✹"]
    for i in 6:
        var b=Button.new(); b.text=names[i]; b.custom_minimum_size=Vector2(62,62); b.add_theme_font_size_override("font_size",27)
        b.tooltip_text="Habilidad %d  •  CD %ss" % [i+1,[1,4,6,9,12,18][i]]
        b.pressed.connect(_on_ability_button.bind(i))
        bar.add_child(b); ability_buttons.append(b)

func _build_joystick():
    var j=TouchScreenButton.new(); j.position=Vector2(42,545)
    var circle=CircleShape2D.new(); circle.radius=70; j.shape=circle
    j.modulate=Color(1,1,1,.18); ui.add_child(j)
    j.pressed.connect(func(): player.set_input(Vector2(0,-1)))
    j.released.connect(func(): player.set_input(Vector2.ZERO))
    var hint=Label.new(); hint.text="◉  MOVER"; hint.position=Vector2(76,602); hint.add_theme_font_size_override("font_size",13); ui.add_child(hint)
    # Botones direccionales táctiles adicionales para Android.
    for data in [[Vector2(92,520),Vector2(0,-1),"▲"],[Vector2(92,635),Vector2(0,1),"▼"],[Vector2(35,577),Vector2(-1,0),"◀"],[Vector2(149,577),Vector2(1,0),"▶"]]:
        var b=Button.new(); b.position=data[0]; b.size=Vector2(45,45); b.text=data[2]; b.modulate=Color(1,1,1,.65); ui.add_child(b)
        b.button_down.connect(func(v=data[1]): player.set_input(v)); b.button_up.connect(func(): player.set_input(Vector2.ZERO))

func _on_ability_button(index:int):
    if player: player.use_ability(index)

func _on_health(v,m):
    if health_bar: health_bar.value=v/m*100.0

func _on_ability(i):
    if status_label: status_label.text=["Golpe de sombra","Lanza púrpura","Tormenta helada","Cometa","Protección","Explosión real"][i]
    var t=Timer.new(); t.one_shot=true; t.wait_time=.7; add_child(t); t.timeout.connect(func(): if status_label: status_label.text="Bosque de Umbral  •  explorando")

func _input(event):
    if event is InputEventScreenTouch and event.pressed:
        # Tap en el mundo: hechizo visual/sonoro puede ampliarse aquí.
        pass
