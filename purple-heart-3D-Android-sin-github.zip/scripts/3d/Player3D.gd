class_name Player3D
extends CharacterBody3D

signal health_changed(value: float, maximum: float)
signal ability_used(index: int)

@export var speed := 7.0
@export var sprint_speed := 10.0
@export var max_health := 100.0
var health := 100.0
var mana := 100.0
var input_vector := Vector2.ZERO
var attack_cooldown := 0.0
var ability_cooldowns := [0.0,0.0,0.0,0.0,0.0,0.0]
var camera_pivot: Node3D
var visual: Node3D
var target_ring: MeshInstance3D

func _ready():
    health = max_health
    _build_body()
    _build_collision()
    health_changed.emit(health, max_health)

func _build_collision():
    var cs=CollisionShape3D.new()
    var capsule=CapsuleShape3D.new()
    capsule.radius=0.45; capsule.height=1.8
    cs.shape=capsule; cs.position.y=0.9
    add_child(cs)

func _mat(c:Color, metallic=0.0, rough=0.6):
    var m=StandardMaterial3D.new()
    m.albedo_color=c; m.metallic=metallic; m.roughness=rough
    return m

func _mesh(primitive:PrimitiveMesh, pos:Vector3, mat:Material, scale_v=Vector3.ONE):
    var n=MeshInstance3D.new(); n.mesh=primitive; n.position=pos; n.scale=scale_v; n.material_override=mat
    visual.add_child(n); return n

func _build_body():
    visual=Node3D.new(); visual.name="HeroVisual"; add_child(visual)
    var skin=_mat(Color("#e8b08a"),0,0.5)
    var cloth=_mat(Color("#3a1b67"),0.05,0.45)
    var armor=_mat(Color("#7d79a5"),0.7,0.25)
    var dark=_mat(Color("#151525"),0.1,0.35)
    var head=SphereMesh.new(); head.radius=.38; head.height=.76
    _mesh(head,Vector3(0,1.62,0),skin)
    var body=CapsuleMesh.new(); body.radius=.42; body.height=1.0
    _mesh(body,Vector3(0,1.02,0),cloth)
    var shoulder=BoxMesh.new(); shoulder.size=Vector3(1.15,.22,.48)
    _mesh(shoulder,Vector3(0,1.28,0),armor)
    var sword=BoxMesh.new(); sword.size=Vector3(.12,1.1,.16)
    var blade=_mesh(sword,Vector3(.66,1.0,.12),dark); blade.rotation.z=-.35
    var glow=OmniLight3D.new(); glow.light_color=Color("#8c4dff"); glow.light_energy=0.7; glow.omni_range=3.2
    glow.position=Vector3(0,1.1,0); visual.add_child(glow)

func set_input(v:Vector2):
    input_vector=v.limit_length(1.0)

func _physics_process(delta):
    for i in ability_cooldowns.size(): ability_cooldowns[i]=max(0.0,ability_cooldowns[i]-delta)
    attack_cooldown=max(0.0,attack_cooldown-delta)
    var v=Vector3(input_vector.x,0,input_vector.y)
    var sp=sprint_speed if Input.is_action_pressed("ui_accept") else speed
    velocity.x=move_toward(velocity.x,v.x*sp,24.0*delta)
    velocity.z=move_toward(velocity.z,v.z*sp,24.0*delta)
    velocity.y=-0.5 if is_on_floor() else velocity.y-18.0*delta
    move_and_slide()
    if v.length()>0.05:
        rotation.y=lerp_angle(rotation.y,atan2(-v.x,-v.z),delta*10.0)
    if target_ring:
        target_ring.position=Vector3(0,0.03,0)

func use_ability(index:int):
    if index<0 or index>=6 or ability_cooldowns[index]>0: return
    ability_cooldowns[index]=[1.0,4.0,6.0,9.0,12.0,18.0][index]
    ability_used.emit(index)

func take_damage(amount:float):
    health=max(0.0,health-amount)
    health_changed.emit(health,max_health)
    if health<=0:
        health=max_health
        global_position=Vector3(0,1,0)
        health_changed.emit(health,max_health)
