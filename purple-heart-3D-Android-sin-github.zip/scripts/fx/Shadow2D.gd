class_name Shadow2D
extends Sprite2D
## (Opcional) Sombra elíptica bajo entidades que no la traen en el sprite (soldados, NPC, caballos).
func _ready() -> void:
	var g := GradientTexture2D.new(); g.fill = GradientTexture2D.FILL_RADIAL; g.fill_from = Vector2(0.5, 0.5); g.fill_to = Vector2(1, 0.5)
	g.width = 64; g.height = 64
	var grad := Gradient.new(); grad.colors = PackedColorArray([Color(0,0,0,0.55), Color(0,0,0,0)]); g.gradient = grad
	texture = g; scale = Vector2(0.9, 0.5); position = Vector2(0, 14); show_behind_parent = true
