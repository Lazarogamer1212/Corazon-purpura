class_name Lighting
extends Node
## Iluminación atmosférica estilo survival/horror: ambiente oscuro, luces con sombras, viñeta,
## ciclo día/noche y partículas de ambiente. Añade este nodo a Castle.tscn (y a cada zona).
@export var ambient_day := Color(0.62, 0.62, 0.78)
@export var ambient_night := Color(0.10, 0.09, 0.20)
@export var day_length := 240.0          # segundos de un ciclo completo
@export var enable_vignette := true
var _mod: CanvasModulate
var _t := 0.0

const VIGNETTE_SHADER := """
shader_type canvas_item;
uniform float intensity = 0.55;
uniform vec4 tint : source_color = vec4(0.05, 0.0, 0.12, 1.0);
void fragment() {
	vec2 uv = UV - 0.5;
	float v = smoothstep(0.25, 0.85, length(uv * vec2(1.0, 1.15)));
	COLOR = vec4(tint.rgb, v * intensity);
}"""

func _ready() -> void:
	_mod = CanvasModulate.new(); _mod.color = ambient_day; add_child(_mod)
	if enable_vignette: _add_vignette()

func _add_vignette() -> void:
	var layer := CanvasLayer.new(); layer.layer = 50; add_child(layer)
	var rect := ColorRect.new(); rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new(); sh.code = VIGNETTE_SHADER
	var mat := ShaderMaterial.new(); mat.shader = sh; rect.material = mat
	layer.add_child(rect)

func _process(delta: float) -> void:
	_t = fmod(_t + delta, day_length)
	var k := 0.5 - 0.5 * cos(TAU * _t / day_length)          # 0 = noche, 1 = día
	_mod.color = ambient_night.lerp(ambient_day, k)

## ¿Es de noche? (los vampiros/monstruos pueden volverse más fuertes por la noche)
func is_night() -> bool: return _mod.color.get_luminance() < 0.3

## Crea una luz puntual con sombra. Úsala para antorchas, linterna del jugador, etc.
static func make_light(color: Color, scale_: float = 2.0, energy: float = 1.0, shadows := true) -> PointLight2D:
	var l := PointLight2D.new()
	l.texture = TextureLib.fx("light_soft"); l.color = color
	l.texture_scale = scale_; l.energy = energy; l.shadow_enabled = shadows
	l.shadow_filter = Light2D.SHADOW_FILTER_PCF5
	return l

## Esmeralda: luz púrpura que late; más fuerte cuanta más vida le queda al Corazón.
static func attach_heart_glow(heart: Node2D) -> PointLight2D:
	var l := make_light(Color(0.62, 0.30, 1.0), 4.5, 1.6, false)
	l.name = "Glow"; heart.add_child(l)
	var tw := l.create_tween().set_loops()
	tw.tween_property(l, "energy", 2.2, 1.4).set_trans(Tween.TRANS_SINE)
	tw.tween_property(l, "energy", 1.2, 1.4).set_trans(Tween.TRANS_SINE)
	return l

## Antorcha parpadeante (colócala sobre muros y entradas).
static func attach_torch(node: Node2D) -> PointLight2D:
	var l := make_light(Color(1.0, 0.62, 0.24), 2.2, 1.2, true); node.add_child(l)
	var tw := l.create_tween().set_loops()
	tw.tween_callback(func(): l.energy = randf_range(0.9, 1.5); l.texture_scale = randf_range(2.0, 2.4))
	tw.tween_interval(0.09)
	return l

## Linterna tenue alrededor de cada jugador (visión en la oscuridad).
static func attach_player_lantern(player: Node2D) -> PointLight2D:
	var l := make_light(Color(1.0, 0.86, 0.6), 2.8, 0.9, true); player.add_child(l); return l

## Partículas ambientales: brasas (ashlands/castillo) o niebla flotante.
static func make_embers(area: Vector2) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.amount = 40; p.lifetime = 6.0; p.preprocess = 6.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE; p.emission_rect_extents = area
	p.direction = Vector2(0.2, -1); p.spread = 25; p.initial_velocity_min = 8; p.initial_velocity_max = 22
	p.scale_amount_min = 1.0; p.scale_amount_max = 2.5; p.color = Color(1.0, 0.55, 0.2, 0.7)
	return p
