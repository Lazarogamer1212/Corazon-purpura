class_name DeathSystem
extends Node
## Muerte de jugador: pierde 1 nivel (mín. 1), sus cosas caen en una MOCHILA recuperable
## y reaparece (castillo o cabaña propia). Se adjunta al jugador, hermano de Health.
const LEVEL_LOSS := 1
const BACKPACK_LIFETIME := 600.0     # 10 min antes de desaparecer
@export var backpack_scene: PackedScene
@export var respawn_delay := 5.0
var inventory: Inventory
var player: CharacterBody2D

func _ready() -> void:
	player = get_parent()
	player.get_node("Health").died.connect(_on_death)

func _on_death(_killer: int) -> void:
	if not multiplayer.is_server(): return
	var peer := player.get_multiplayer_authority()
	# 1) Mochila con todo el inventario y parte del oro personal
	var bp := backpack_scene.instantiate()
	bp.global_position = player.global_position
	bp.setup(peer, inventory.drain_all(), int(Profile.data.gold_personal * 0.5), BACKPACK_LIFETIME)
	player.get_tree().current_scene.get_node("Pickups").add_child(bp, true)
	# 2) Penalización de nivel
	_penalize.rpc_id(peer)
	# 3) Respawn
	player.visible = false
	await player.get_tree().create_timer(respawn_delay).timeout
	_respawn.rpc_id(peer, _respawn_point(peer))

func _respawn_point(peer: int) -> Vector2:
	var cabins := player.get_tree().get_nodes_in_group("cabins")
	for c in cabins:
		if c.owner_peer == peer: return c.global_position + Vector2(0, 30)
	return player.get_tree().get_first_node_in_group("respawn_castle").global_position

@rpc("authority", "call_local", "reliable")
func _penalize() -> void:
	var p := Profile.data
	p.level = maxi(1, p.level - LEVEL_LOSS)
	p.xp = 0
	p.gold_personal = int(p.gold_personal * 0.5)
	Profile.save()

@rpc("authority", "call_local", "reliable")
func _respawn(pos: Vector2) -> void:
	player.global_position = pos
	player.visible = true
	player.get_node("Health").hp = player.get_node("Health").max_hp
