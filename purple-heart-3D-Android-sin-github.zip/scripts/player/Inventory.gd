class_name Inventory
extends Node
## Inventario por slots (24). Ítems: {id, name, qty, type: food|material|weapon|armor|barding|seed}
signal changed
const SLOTS := 24
var items: Array[Dictionary] = []

func add(item: Dictionary) -> bool:
	for it in items:
		if it.id == item.id and it.get("stackable", true):
			it.qty += item.qty; changed.emit(); return true
	if items.size() >= SLOTS: return false
	items.append(item.duplicate()); changed.emit(); return true

func remove(id: String, qty := 1) -> bool:
	for it in items:
		if it.id == id and it.qty >= qty:
			it.qty -= qty
			if it.qty == 0: items.erase(it)
			changed.emit(); return true
	return false

func count(id: String) -> int:
	for it in items: if it.id == id: return it.qty
	return 0

func drain_all() -> Array:
	var all := items.duplicate(true); items.clear(); changed.emit(); return all

@rpc("authority", "reliable")
func receive_loot(loot: Array, gold: int) -> void:
	for it in loot: add(it)
	Profile.data.gold_personal += gold
	Profile.save()
