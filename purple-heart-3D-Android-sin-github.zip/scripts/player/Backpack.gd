class_name Backpack
extends Area2D
## Mochila de muerte. Solo su dueño (o cualquiera tras 60 s) puede recogerla.
var owner_peer := 0
var contents: Array = []
var gold := 0
var _age := 0.0
var _lifetime := 600.0

func setup(peer: int, items: Array, g: int, lifetime: float) -> void:
	owner_peer = peer; contents = items; gold = g; _lifetime = lifetime
	add_to_group("backpacks")

func _ready() -> void:
	body_entered.connect(_on_body)

func _process(delta: float) -> void:
	if not multiplayer.is_server(): return
	_age += delta
	if _age >= _lifetime: queue_free()

func _on_body(body: Node) -> void:
	if not multiplayer.is_server() or not body.is_in_group("players"): return
	var peer := body.get_multiplayer_authority()
	if peer != owner_peer and _age < 60.0: return      # protección del dueño 60 s
	body.get_node("Inventory").receive_loot.rpc_id(peer, contents, gold)
	queue_free()
