extends Node
## XP / niveles (autoload "ProgressionSystem"). Servidor autoritativo.
func grant_xp(peer_id: int, xp: int) -> void:
	if not multiplayer.is_server(): return
	_award.rpc_id(peer_id, xp) if peer_id != 1 else _award(xp)

@rpc("authority", "reliable")
func _award(xp: int) -> void:
	var p := Profile.data
	p.xp += xp
	while p.xp >= ClassDB.xp_for_level(p.level):
		p.xp -= ClassDB.xp_for_level(p.level)
		p.level += 1
		p.skill_points += 1
		if p.level % 3 == 0: p.int_stat += 1
		EventBus.level_up.emit(multiplayer.get_unique_id(), p.level)
	Profile.save()
