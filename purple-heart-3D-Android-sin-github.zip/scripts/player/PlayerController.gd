class_name PlayerController
extends CharacterBody2D
## Jugador top-down con joystick virtual (landscape). Autoridad = cada cliente sobre su movimiento.
## Nodos: Health, Hunger, Inventory, DeathSystem, Mount, MultiplayerSynchronizer, Sprite2D.
@export var joystick_path: NodePath          # VirtualJoystick (Control, UI)
@onready var health: Health = $Health
@onready var hunger: Hunger = $Hunger
@onready var mount: Mount = $Mount
var cd := {}                                # skill_id -> tiempo restante

func _enter_tree() -> void:
	set_multiplayer_authority(name.to_int())  # el nombre del nodo = peer_id

func _ready() -> void:
	add_to_group("players")
	hunger.health = health
	mount.rider_profile = Profile.data
	Lighting.attach_player_lantern(self)

func apply_skin(skin_id: int, color: Color) -> void:
	$Sprite2D.texture = TextureLib.skin(skin_id)
	$Sprite2D.modulate = color

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority(): return
	var joy: Vector2 = get_node(joystick_path).output if joystick_path else Input.get_vector("ui_left","ui_right","ui_up","ui_down")
	var spd: float = ClassDB.get_class_data(Profile.data.class_id).speed
	velocity = joy * spd * mount.speed_multiplier() * hunger.speed_penalty()
	move_and_slide()
	if velocity.length() > 5.0: $Sprite2D.rotation = lerp_angle($Sprite2D.rotation, velocity.angle(), 0.25)
	for k in cd.keys(): cd[k] = maxf(0.0, cd[k] - delta)

func use_skill(index: int) -> void:
	if not mount.can_attack(): return
	var skills: Array = ClassDB.get_class_data(Profile.data.class_id).skills
	if index >= skills.size(): return
	var s: Dictionary = skills[index]
	if cd.get(s.id, 0.0) > 0.0: return
	cd[s.id] = s.cd
	_cast.rpc_id(1, s.id)          # el servidor resuelve el daño y lo replica

@rpc("any_peer", "call_local", "reliable")
func _cast(skill_id: String) -> void:
	if not multiplayer.is_server(): return
	# Resolver por 'type' (aoe_melee, projectile, heal_ally...): consulta ClassDB, aplica
	# Health.apply_damage() a los objetivos en rango. Ver README para la tabla de tipos.
	pass
