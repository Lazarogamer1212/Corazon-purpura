#!/usr/bin/env python3
"""Texturas HD (64x64) semi-realistas, vista cenital, para Corazón Púrpura. Licencia: CC0.
Técnica: dibujo supersampleado x4 + mapas de altura con iluminación (bevel/relieve) + sombra proyectada.
Personajes y monstruos miran a la DERECHA (+X) para poder rotar el Sprite2D hacia la dirección de movimiento.
Uso: pip install pillow numpy && python3 tools/generate_hd_textures.py"""
import os, math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "hd")
N = 64          # tamaño final
SS = 4          # supersampling
W = N * SS
LIGHT = np.array([-0.55, -0.65, 0.52]); LIGHT /= np.linalg.norm(LIGHT)   # luz desde arriba-izquierda

def hexc(h): h = h.lstrip("#"); return np.array([int(h[i:i+2], 16) for i in (0, 2, 4)], dtype=np.float32)
def save(img, *p):
    path = os.path.join(OUT, *p); os.makedirs(os.path.dirname(path), exist_ok=True); img.save(path)

# ---------- Utilidades de ruido / iluminación ----------
def tile_noise(size, octaves, rng):
    """Ruido de valor TILEABLE (se repite sin costuras). Devuelve array 0..1 de size x size."""
    out = np.zeros((size, size), np.float32); amp = 1.0; tot = 0.0
    for o in octaves:
        g = rng.random((o, o)).astype(np.float32)
        big = np.tile(g, (3, 3))
        im = Image.fromarray((big * 255).astype(np.uint8)).resize((3 * size, 3 * size), Image.BICUBIC)
        a = np.asarray(im, np.float32)[size:2 * size, size:2 * size] / 255.0
        out += a * amp; tot += amp; amp *= 0.5
    return out / tot

def shade(height, albedo, strength=2.2, ambient=0.55):
    """Ilumina un mapa de alturas (relieve) con color albedo (HxWx3). Devuelve RGB uint8."""
    gy, gx = np.gradient(height)
    nx, ny, nz = -gx * strength, -gy * strength, np.ones_like(height)
    ln = np.sqrt(nx ** 2 + ny ** 2 + nz ** 2)
    d = (nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2]) / ln
    lit = np.clip(ambient + (1 - ambient) * d * 1.15, 0.15, 1.45)
    return np.clip(albedo * lit[..., None], 0, 255).astype(np.uint8)

def colorize(n, lo, hi):
    lo, hi = hexc(lo), hexc(hi); return lo + (hi - lo) * n[..., None]

def to_img(rgb): return Image.fromarray(rgb, "RGB").convert("RGBA")

# ---------- TILES ----------
def tile_bricks(rng, face_lo, face_hi, mortar, bw=16, bh=8, bevel=3):
    h = np.zeros((N, N), np.float32); alb = np.zeros((N, N, 3), np.float32); mt = hexc(mortar)
    var = tile_noise(N, [4, 8, 16], rng)
    for r, y in enumerate(range(0, N, bh)):
        off = (bw // 2) if r % 2 else 0
        for x in range(-off, N, bw):
            tone = rng.random() * 0.5 + 0.25
            for yy in range(y, y + bh):
                for xx in range(x, x + bw):
                    px, py = xx % N, yy % N
                    dx = min(xx - x, x + bw - 1 - xx); dy = min(yy - y, y + bh - 1 - yy)
                    e = min(dx, dy)
                    if e < 1: h[py, px] = 0.0; alb[py, px] = mt * 0.7
                    else:
                        h[py, px] = min(1.0, e / bevel) * 0.9 + var[py, px] * 0.15
                        alb[py, px] = hexc(face_lo) + (hexc(face_hi) - hexc(face_lo)) * np.clip(tone + (var[py, px] - 0.5) * 0.9, 0, 1)
    return h, alb

def make_tiles():
    rng = np.random.default_rng(11); t = {}
    def put(name, h, alb, **kw): t[name] = to_img(shade(h, alb, **kw))
    h, a = tile_bricks(rng, "#4a4858", "#6b6880", "#1c1a24"); put("castle_wall_stone", h, a)
    # suelo de losas oscuras
    h, a = tile_bricks(rng, "#2f2d3a", "#464355", "#14121b", 32, 32, 2); put("castle_floor", h, a, strength=1.6)
    # madera (tablones con vetas)
    n = tile_noise(N, [2, 16, 32], rng); h = np.zeros((N, N), np.float32); alb = np.zeros((N, N, 3), np.float32)
    for y in range(N):
        pl = y // 16; edge = min(y % 16, 15 - y % 16)
        grain = np.sin((np.arange(N) * 0.35) + n[y] * 6 + pl * 3) * 0.5 + 0.5
        h[y] = np.minimum(1, edge / 2.0) * 0.8 + grain * 0.1
        alb[y] = colorize(np.clip(grain * 0.5 + n[y] * 0.6 + pl * 0.05, 0, 1)[None, :], "#4b2f1c", "#8a5c36")[0] * (0.35 if edge == 0 else 1.0)
    put("wood_floor", h, alb)
    h, a = tile_bricks(rng, "#7a5233", "#a06f42", "#2e1d10", 64, 16, 3); put("wall_wood", h, a)
    h, a = tile_bricks(rng, "#6b7488", "#aab3c6", "#262b38", 16, 16, 4)
    for cx in (3, 12):
        for cy in (3, 12):                                       # remaches
            for x0 in range(0, N, 16):
                for y0 in range(0, N, 16):
                    yy, xx = np.ogrid[:N, :N]; m = (xx - (x0 + cx)) ** 2 + (yy - (y0 + cy)) ** 2 < 2.5
                    h[m] += 0.6; a[m] = hexc("#d6dcea")
    put("wall_steel", h, a, strength=2.8)
    n = tile_noise(N, [4, 8, 16, 32], rng); fine = rng.random((N, N)).astype(np.float32)
    put("grass", n * 0.6 + fine * 0.5, colorize(np.clip(n * 0.9 + fine * 0.25, 0, 1), "#2a4a27", "#5d9448"), strength=1.4)
    put("dirt", n + fine * 0.3, colorize(np.clip(n + (fine - 0.5) * 0.4, 0, 1), "#4a3825", "#7f6446"), strength=1.8)
    put("swamp", n, colorize(np.clip(n + (tile_noise(N, [8, 16], rng) - 0.5) * 0.5, 0, 1), "#27321c", "#5a6b3a"), strength=1.2)
    put("sand", tile_noise(N, [8, 16, 32], rng) * 0.6, colorize(n, "#a38a56", "#cdb67b"), strength=1.6)
    emb = (tile_noise(N, [16, 32], rng) > 0.78).astype(np.float32)
    a = colorize(n, "#231e29", "#4a4153"); a = a * (1 - emb[..., None]) + hexc("#c2451c") * emb[..., None]
    put("ashlands", n, a, strength=2.0)
    wv = tile_noise(N, [4, 8], rng); caust = np.abs(np.sin(wv * 18)); a = colorize(wv, "#1f3d63", "#3b6a9c") + (caust[..., None] ** 8) * 90
    put("water", wv * 0.5, np.clip(a, 0, 255), strength=1.0)
    # alfombra real
    yy, xx = np.mgrid[:N, :N]; bord = np.minimum(np.minimum(xx, N - 1 - xx), np.minimum(yy, N - 1 - yy))
    a = colorize(n, "#34175a", "#53298c"); a[bord < 4] = hexc("#d4a62a"); a[(bord == 4) | (bord == 7)] = hexc("#8a6a14")
    put("carpet_purple", n * 0.4 + (bord < 4) * 0.2, a, strength=1.0)
    for name, base_lo, base_hi in [("gate_wood_tile", "#5a3a22", "#8a5c36"), ("gate_steel_tile", "#4a5266", "#8a94aa")]:
        h = np.zeros((N, N), np.float32); alb = np.zeros((N, N, 3), np.float32)
        for x in range(N):
            pe = min(x % 14, 13 - x % 14); h[:, x] = np.minimum(1, pe / 2.0)
        alb[:] = colorize(np.clip(n + 0.1, 0, 1), base_lo, base_hi)
        for y0 in (10, 46):
            h[y0:y0 + 7, :] = 1.2; alb[y0:y0 + 7, :] = hexc("#3a4150")
        put(name, h, alb, strength=2.6)
    return t

# ---------- SPRITES SUPERSAMPLEADOS ----------
class Canvas:
    def __init__(self): self.rgb = np.zeros((W, W, 3), np.float32); self.a = np.zeros((W, W), np.float32)
    def part(self, draw_fn, color, relief=0.9, blur=7, tex=0.0, rim=0.0):
        m = Image.new("L", (W, W), 0); draw_fn(ImageDraw.Draw(m))
        mk = np.asarray(m, np.float32) / 255.0
        hgt = np.asarray(m.filter(ImageFilter.GaussianBlur(blur)), np.float32) / 255.0 * relief * 6
        col = np.broadcast_to(hexc(color) if isinstance(color, str) else color, (W, W, 3)).copy()
        if tex: col *= (1 + (np.random.default_rng(3).random((W, W)).astype(np.float32) - 0.5) * tex)[..., None]
        lit = shade(hgt, col, strength=2.4, ambient=0.5).astype(np.float32)
        if rim:  # contorno oscuro
            ed = np.asarray(m.filter(ImageFilter.MinFilter(5)), np.float32) / 255.0
            lit *= (1 - (mk - ed)[..., None] * rim)
        self.rgb = self.rgb * (1 - mk[..., None]) + lit * mk[..., None]; self.a = np.maximum(self.a, mk)
    def finish(self, shadow=0.55):
        mk = (self.a * 255).astype(np.uint8)
        sh = Image.fromarray(mk).filter(ImageFilter.GaussianBlur(SS * 2.2))
        sh = np.asarray(sh, np.float32) / 255.0 * shadow
        sh = np.roll(np.roll(sh, 3 * SS, axis=0), 2 * SS, axis=1)
        out = np.zeros((W, W, 4), np.float32)
        out[..., :3] = self.rgb * self.a[..., None]; out[..., 3] = np.maximum(self.a, sh) * 255
        # sombra: RGB negro donde no hay sprite (alpha premultiplicado -> recuperar color)
        a = np.maximum(self.a, sh); out[..., :3] = np.where(self.a[..., None] > 0.01, self.rgb, 0)
        out[..., :3] = np.clip(out[..., :3], 0, 255)
        img = Image.fromarray(out.astype(np.uint8), "RGBA").resize((N, N), Image.LANCZOS)
        return img
def S(v): return int(round(v * SS))
def ell(d, cx, cy, rx, ry): d.ellipse([S(cx - rx), S(cy - ry), S(cx + rx), S(cy + ry)], fill=255)
def poly(d, pts): d.polygon([(S(x), S(y)) for x, y in pts], fill=255)
def rect(d, x0, y0, x1, y1, r=0): d.rounded_rectangle([S(x0), S(y0), S(x1), S(y1)], radius=S(r), fill=255)

def humanoid_top(c, skin, hair, torso, arms, accessory=None, size=1.0, eye=None, claws=False, headcolor=None, pants=None):
    """Humanoide visto desde arriba, mirando a la derecha. Coordenadas en 0..64."""
    s = size; cx = 30
    c.part(lambda d: (ell(d, cx - 7 * s, 22, 5.5 * s, 4.2 * s), ell(d, cx - 7 * s, 42, 5.5 * s, 4.2 * s)), pants or "#3d3d4a", 0.7)   # piernas/hombros atrás
    for sgn in (-1, 1):                                                                                   # brazos extendidos hacia delante
        c.part(lambda d, sgn=sgn: (d.line([S(cx), S(32 + sgn * 9 * s), S(cx + 12 * s), S(32 + sgn * 6 * s)], fill=255, width=S(5 * s)),
                                   ell(d, cx + 13 * s, 32 + sgn * 6 * s, 3.2 * s, 3.2 * s)), arms, 0.8)
    c.part(lambda d: ell(d, cx, 32, 9 * s, 12 * s), torso, 1.0, rim=0.5)                                  # torso
    c.part(lambda d: ell(d, cx + 3 * s, 32, 7 * s, 7 * s), headcolor or skin, 1.1, rim=0.5)               # cabeza
    c.part(lambda d: ell(d, cx + 0.5 * s, 32, 7.2 * s, 7.4 * s), hair, 1.0, tex=0.35)                     # pelo (cubre atrás)
    c.part(lambda d: ell(d, cx + 5 * s, 32, 4.5 * s, 5.2 * s), headcolor or skin, 0.8)                    # cara
    if eye:
        for sgn in (-1, 1): c.part(lambda d, sgn=sgn: ell(d, cx + 8 * s, 32 + sgn * 2.5 * s, 1.1 * s, 1.1 * s), eye, 0.2)
    if accessory: accessory(c, cx, s)

def make_skins():
    skin_tones = ["#e0b48c", "#c68c5a", "#8d5a3b", "#f1cfae"]
    cloth = "#9a9aa8"                                   # neutro claro para teñirse con el color del perfil
    def helm(c, cx, s): c.part(lambda d: ell(d, cx + 2 * s, 32, 8 * s, 8 * s), "#8c96ab", 1.2, rim=0.6); c.part(lambda d: rect(d, cx + 1 * s, 30, cx + 10 * s, 34, 1), "#2a2e3a", 0.4)
    def hood(c, cx, s): c.part(lambda d: ell(d, cx + 1 * s, 32, 9 * s, 9 * s), "#7a7a88", 1.1, tex=0.2)
    def crown(c, cx, s): c.part(lambda d: ell(d, cx + 3 * s, 32, 6 * s, 6 * s), "#e8b923", 1.2, rim=0.5); c.part(lambda d: ell(d, cx + 3 * s, 32, 3.5 * s, 3.5 * s), "#5b21a8", 0.8)
    def cape(c, cx, s): c.part(lambda d: ell(d, cx - 5 * s, 32, 7 * s, 14 * s), "#5b21a8", 0.8, tex=0.15)
    def hat(c, cx, s): c.part(lambda d: ell(d, cx + 1 * s, 32, 11 * s, 11 * s), "#4a2f6a", 0.9); c.part(lambda d: ell(d, cx + 1 * s, 32, 5.5 * s, 5.5 * s), "#5f3c85", 1.3)
    def horns(c, cx, s): c.part(lambda d: (poly(d, [(cx + 4, 22), (cx + 10, 18), (cx + 7, 25)]), poly(d, [(cx + 4, 42), (cx + 10, 46), (cx + 7, 39)])), "#e8e2cf", 0.9)
    def scarf(c, cx, s): c.part(lambda d: ell(d, cx - 1 * s, 32, 4 * s, 9 * s), "#a82a2a", 0.9)
    cfg = [(0, "#4a3020", None), (1, "#161616", scarf), (2, "#2a1a10", helm), (3, "#d8b45a", cape), (0, "#8a8a95", hood),
           (1, "#a8321e", horns), (2, "#101010", hat), (3, "#7a5a3a", lambda c, cx, s: (cape(c, cx, s), crown(c, cx, s)))]
    out = []
    for i, (st, hair, acc) in enumerate(cfg):
        c = Canvas(); humanoid_top(c, skin_tones[st], hair, cloth, skin_tones[st], acc, eye=None, pants="#4b4b5c"); out.append(c.finish())
    return out

# monstruos: (plantilla, color, color2, ojos, deco, tamaño)
M = {"skeleton":("h","#e3dcc4","#bfb79d","#ff3030",None,1.0),"zombie":("h","#6f9060","#4b5f3d","#ffe040",None,1.0),
 "vampire":("h","#d9c9d3","#5a1020","#ff2020","cape",1.0),"bat":("fly","#3a3048","#241c2e","#ff2020",None,0.9),
 "wraith":("h","#9fb8e0","#6e86b0","#ffffff","ghost",1.0),"ghoul":("h","#8a8f78","#5e6350","#ff9a20","claws",1.05),
 "werewolf":("beast","#6b5a4a","#3f332a","#ffd020",None,1.1),"spider":("spider","#2d2d35","#4a4a58","#ff2020",None,0.9),
 "goblin":("h","#6aa84f","#4a7a38","#ffe040",None,0.75),"orc":("h","#4f7a3c","#3a5a2c","#ff4040","claws",1.25),
 "troll":("h","#6a7a5a","#4a5a40","#ffe040","claws",1.45),"imp":("h","#c0392b","#7a1f16","#ffe040","horns",0.8),
 "harpy":("fly","#a07a5a","#6e4e36","#ffe040",None,1.0),"golem":("h","#7a7a88","#4f4f5c","#9b4dff","rock",1.55),
 "slime":("blob","#4fc46a","#9be8ab","#101010",None,1.0),"cultist":("h","#3a2a55","#251840","#ff3030","hood",1.0),
 "gargoyle":("fly","#6a6a78","#4a4a56","#ff3030",None,1.25),"banshee":("h","#cfe4ff","#9fb8e0","#40a0ff","ghost",1.0),
 "lich":("h","#d8d8c0","#3a1c63","#9b4dff","crown",1.1),"demon":("h","#a82a2a","#5a1414","#ffe040","horns",1.45),
 "wyrm":("snake","#3f7a4a","#244a2e","#ffe040",None,1.2),"mummy":("h","#d8cfa8","#b0a680","#ff3030",None,1.0),
 "scorpion":("spider","#b58a3a","#7a5a1e","#101010",None,1.1),"knight_fallen":("h","#6b7488","#394052","#ff3030","helm",1.15),
 "treant":("h","#5a4228","#2f5a30","#ffe040","rock",1.6),"hound":("beast","#2a2a30","#6a1a1a","#ff6020",None,1.0),
 "witch":("h","#6a8a5a","#3a1c63","#a0ff40","hat",1.0),"shade":("h","#2a2236","#14101c","#9b4dff","ghost",1.0),
 "drake":("fly","#a83a2a","#5a1c14","#ffe040",None,1.5),"abomination":("h","#7a5a6a","#4a1a30","#ff3030","extra",1.7)}

def make_monster(fam):
    t, c1, c2, eye, deco, sz = M[fam]; c = Canvas(); rng = random.Random(hash(fam) & 0xffff)
    if t == "h":
        s = min(sz, 1.3)
        humanoid_top(c, c1, c2 if deco != "hood" else c2, c2, c1, None, size=s, eye=eye, pants=c2)
        if deco == "horns": c.part(lambda d: (poly(d, [(33, 24), (42, 20), (37, 27)]), poly(d, [(33, 40), (42, 44), (37, 37)])), "#e8e2cf", 0.9)
        if deco in ("hood", "hat"): c.part(lambda d: ell(d, 31, 32, 9 * s, 9.5 * s), c2, 1.2, tex=0.2)
        if deco == "helm": c.part(lambda d: ell(d, 32, 32, 8 * s, 8 * s), "#8c96ab", 1.2, rim=0.6)
        if deco == "crown": c.part(lambda d: ell(d, 33, 32, 5.5, 5.5), "#e8b923", 1.2, rim=0.5)
        if deco == "rock":
            for _ in range(5): c.part(lambda d: ell(d, rng.uniform(22, 38), rng.uniform(22, 42), 4, 4), c2, 1.3, tex=0.4)
        if deco == "claws":
            for sgn in (-1, 1): c.part(lambda d, sgn=sgn: poly(d, [(46, 32 + sgn * 6), (56, 32 + sgn * 9), (46, 32 + sgn * 9)]), "#e8e2cf", 0.8)
        if deco == "cape": c.part(lambda d: poly(d, [(26, 20), (6, 12), (10, 32), (6, 52), (26, 44)]), "#4a0c18", 0.7)
        if deco == "extra":
            for k in range(4): c.part(lambda d, k=k: ell(d, 30 + k * 3, 22 + rng.uniform(0, 20), 2.5, 2.5), eye, 0.3)
    elif t == "beast":
        c.part(lambda d: ell(d, 26, 32, 15, 9), c2, 1.0, tex=0.35, rim=0.4)
        for x in (16, 36):
            for sgn in (-1, 1): c.part(lambda d, x=x, sgn=sgn: ell(d, x, 32 + sgn * 10, 5, 3), c2, 0.8)
        c.part(lambda d: ell(d, 44, 32, 8, 6.5), c1, 1.1, rim=0.4); c.part(lambda d: poly(d, [(48, 28), (60, 31), (48, 33)]), c1, 0.9)
        c.part(lambda d: poly(d, [(40, 25), (44, 20), (45, 26)]), c2, 0.6); c.part(lambda d: poly(d, [(40, 39), (44, 44), (45, 38)]), c2, 0.6)
        for sgn in (-1, 1): c.part(lambda d, sgn=sgn: ell(d, 48, 32 + sgn * 3, 1.2, 1.2), eye, 0.2)
        c.part(lambda d: poly(d, [(12, 31), (2, 28), (4, 33), (12, 34)]), c2, 0.7)
    elif t == "fly":
        sp = 28 * sz / 1.3
        for sgn in (-1, 1):
            c.part(lambda d, sgn=sgn: poly(d, [(26, 32), (14, 32 + sgn * sp), (30, 32 + sgn * (sp * 0.7)), (40, 32 + sgn * 6)]), c2, 0.7, tex=0.25, rim=0.5)
        c.part(lambda d: ell(d, 30, 32, 10, 5), c1, 1.1, rim=0.5); c.part(lambda d: ell(d, 40, 32, 5, 4.5), c1, 1.1, rim=0.5)
        for sgn in (-1, 1): c.part(lambda d, sgn=sgn: ell(d, 43, 32 + sgn * 2, 1.1, 1.1), eye, 0.2)
    elif t == "spider":
        for k in range(4):
            for sgn in (-1, 1):
                y0 = 28 + k * 2.5
                c.part(lambda d, k=k, sgn=sgn, y0=y0: (d.line([S(30), S(32), S(30 + (k - 1.5) * 6), S(32 + sgn * 14)], fill=255, width=S(2.2)),
                                                          d.line([S(30 + (k - 1.5) * 6), S(32 + sgn * 14), S(30 + (k - 1.5) * 9), S(32 + sgn * 26)], fill=255, width=S(2.0))), c2, 0.5)
        c.part(lambda d: ell(d, 24, 32, 9, 8), c1, 1.1, tex=0.3, rim=0.5); c.part(lambda d: ell(d, 38, 32, 6, 5.5), c1, 1.1, rim=0.5)
        for sgn in (-1, 1):
            for k in (0, 1): c.part(lambda d, sgn=sgn, k=k: ell(d, 42, 32 + sgn * (1.5 + k * 2.2), 1.0, 1.0), eye, 0.2)
    elif t == "blob":
        c.part(lambda d: ell(d, 32, 32, 20, 18), c1, 1.8, tex=0.1, rim=0.3); c.part(lambda d: ell(d, 26, 26, 7, 5), c2, 1.0)
        for sgn in (-1, 1): c.part(lambda d, sgn=sgn: ell(d, 42, 32 + sgn * 4, 2, 2.5), eye, 0.2)
    elif t == "snake":
        pts = [(8, 44), (16, 38), (24, 40), (32, 34), (40, 36), (48, 30)]
        for i, (x, y) in enumerate(pts):
            c.part(lambda d, x=x, y=y, i=i: ell(d, x, y, 6 + i * 0.4, 5.5 + i * 0.4), c1 if i % 2 else c2, 1.2, rim=0.5)
        c.part(lambda d: ell(d, 54, 28, 7, 6), c1, 1.2, rim=0.5)
        for sgn in (-1, 1): c.part(lambda d, sgn=sgn: ell(d, 57, 28 + sgn * 2.5, 1.2, 1.2), eye, 0.2)
    img = c.finish()
    if deco == "ghost":                                    # espectros semitransparentes
        a = np.asarray(img).copy(); a[..., 3] = (a[..., 3] * 0.72).astype(np.uint8); img = Image.fromarray(a, "RGBA")
    return img

# ---------- OBJETOS ----------
def make_objects():
    o = {}; rng = random.Random(5)
    c = Canvas(); c.part(lambda d: ell(d, 32, 40, 17, 12), "#555266", 1.4, rim=0.6)                       # pedestal
    c.part(lambda d: poly(d, [(32, 6), (50, 22), (50, 40), (32, 56), (14, 40), (14, 22)]), "#8a3fe8", 1.6, rim=0.7)
    c.part(lambda d: poly(d, [(32, 6), (14, 22), (32, 30)]), "#d6aaff", 1.2); c.part(lambda d: poly(d, [(32, 30), (14, 22), (14, 40), (32, 56)]), "#5a22a8", 1.0)
    c.part(lambda d: ell(d, 25, 20, 3, 4), "#ffffff", 0.2); o["castle_heart"] = c.finish(0.5)
    c = Canvas(); c.part(lambda d: rect(d, 8, 12, 56, 56, 3), "#8a3a2a", 1.3, tex=0.3, rim=0.6)            # cabaña: tejado visto desde arriba
    c.part(lambda d: poly(d, [(8, 12), (32, 34), (8, 56)]), "#a24a36", 1.0); c.part(lambda d: rect(d, 30, 12, 34, 56), "#5a2a1e", 0.8); o["cabin"] = c.finish()
    c = Canvas(); c.part(lambda d: rect(d, 16, 14, 48, 54, 8), "#8a5a2f", 1.4, tex=0.3, rim=0.6); c.part(lambda d: rect(d, 20, 8, 44, 24, 6), "#6a4422", 1.2)
    c.part(lambda d: rect(d, 16, 34, 48, 40), "#3a2a1a", 0.6); c.part(lambda d: rect(d, 29, 30, 35, 44, 2), "#e8b923", 1.0, rim=0.5); o["backpack"] = c.finish()
    c = Canvas()
    for x, y in [(18, 24), (36, 18), (44, 40), (22, 44), (32, 32)]:
        c.part(lambda d, x=x, y=y: ell(d, x, y, 6, 6), "#ece6d8", 1.3, rim=0.4); c.part(lambda d, x=x, y=y: poly(d, [(x - 1, y - 6), (x + 1, y - 6), (x, y - 12)]), "#4f8447", 0.5)
    o["garlic"] = c.finish(0.4)
    c = Canvas(); c.part(lambda d: ell(d, 32, 32, 18, 18), "#555266", 1.4, rim=0.6)
    for k in range(8):
        a = k * math.pi / 4; c.part(lambda d, a=a: poly(d, [(32 + 8 * math.cos(a - .25), 32 + 8 * math.sin(a - .25)), (32 + 26 * math.cos(a), 32 + 26 * math.sin(a)), (32 + 8 * math.cos(a + .25), 32 + 8 * math.sin(a + .25))]), "#a87a48", 0.9, rim=0.5)
    o["stake_turret"] = c.finish()
    c = Canvas(); c.part(lambda d: ell(d, 26, 32, 16, 10), "#8a5a3a", 1.2, tex=0.2, rim=0.4); c.part(lambda d: ell(d, 46, 32, 8, 6), "#8a5a3a", 1.1)
    c.part(lambda d: poly(d, [(50, 29), (62, 31), (50, 35)]), "#6a4326", 0.9); c.part(lambda d: rect(d, 10, 28, 40, 36), "#2a1a10", 0.6); o["horse"] = c.finish()
    c = Canvas(); c.part(lambda d: ell(d, 26, 32, 16, 10), "#8a5a3a", 1.2, tex=0.2, rim=0.4); c.part(lambda d: ell(d, 46, 32, 8, 6), "#8a5a3a", 1.1)
    c.part(lambda d: rect(d, 14, 24, 38, 40, 4), "#aab3c6", 1.4, rim=0.6); c.part(lambda d: ell(d, 46, 32, 6, 5), "#8a94aa", 1.3, rim=0.6); o["horse_armored"] = c.finish()
    c = Canvas(); humanoid_top(c, "#e0b48c", "#3a2a1a", "#2f4f8a", "#aab3c6", None, pants="#3d3d4a")
    c.part(lambda d: ell(d, 33, 32, 7.5, 7.5), "#8c96ab", 1.3, rim=0.6); c.part(lambda d: ell(d, 14, 22, 7, 9), "#6b7488", 1.3, rim=0.6)
    c.part(lambda d: rect(d, 40, 29, 62, 32), "#c9d1e0", 0.9, rim=0.5); o["soldier"] = c.finish()
    c = Canvas(); humanoid_top(c, "#e0b48c", "#d8d8d8", "#7a3a2a", "#e0b48c", None, pants="#4a3a2a"); c.part(lambda d: ell(d, 32, 14, 4, 4), "#e8b923", 1.2, rim=0.5); o["npc_quest"] = c.finish()
    c = Canvas(); c.part(lambda d: ell(d, 32, 32, 14, 14), "#e8b923", 1.6, rim=0.7); c.part(lambda d: ell(d, 32, 32, 9, 9), "#c58f0f", 0.6); c.part(lambda d: ell(d, 27, 27, 3, 3), "#fff2b0", 0.2); o["gold_coin"] = c.finish(0.4)
    c = Canvas(); c.part(lambda d: rect(d, 8, 16, 56, 50, 4), "#7a5233", 1.3, tex=0.3, rim=0.6); c.part(lambda d: rect(d, 8, 16, 56, 30, 4), "#a06f42", 1.2)
    c.part(lambda d: rect(d, 8, 28, 56, 33), "#6b7488", 0.8); c.part(lambda d: rect(d, 28, 26, 36, 38, 2), "#e8b923", 1.0, rim=0.5); o["chest"] = c.finish()
    c = Canvas(); c.part(lambda d: ell(d, 32, 32, 6, 6), "#4a3020", 1.0)
    for cx, cy, r in [(32, 32, 26), (20, 24, 14), (44, 26, 14), (22, 42, 14), (44, 42, 15)]:
        c.part(lambda d, cx=cx, cy=cy, r=r: ell(d, cx, cy, r, r), "#2f5a30", 1.6, tex=0.5)
    o["tree"] = c.finish(0.6)
    c = Canvas(); c.part(lambda d: ell(d, 30, 32, 17, 11), "#a85a34", 1.4, rim=0.5); c.part(lambda d: rect(d, 40, 28, 58, 36, 3), "#e8e2cf", 1.0, rim=0.5); c.part(lambda d: ell(d, 24, 28, 5, 3), "#d98a60", 0.6); o["food_meat"] = c.finish(0.4)
    c = Canvas(); c.part(lambda d: ell(d, 32, 34, 20, 15), "#6a6a78", 1.8, tex=0.5, rim=0.5); c.part(lambda d: ell(d, 26, 28, 9, 6), "#8a8a98", 1.3); o["rock"] = c.finish()
    c = Canvas(); c.part(lambda d: rect(d, 20, 8, 44, 58, 10), "#8a8a98", 1.4, tex=0.4, rim=0.6); c.part(lambda d: rect(d, 30, 16, 34, 34), "#4a4a58", 0.5); c.part(lambda d: rect(d, 24, 22, 40, 26), "#4a4a58", 0.5); o["tombstone"] = c.finish()
    c = Canvas(); c.part(lambda d: ell(d, 32, 40, 5, 12), "#5a3a22", 1.0); c.part(lambda d: ell(d, 32, 22, 9, 9), "#ff9a2a", 1.0); c.part(lambda d: ell(d, 32, 22, 5, 5), "#fff2b0", 0.5); o["torch"] = c.finish(0.3)
    c = Canvas(); c.part(lambda d: ell(d, 32, 32, 20, 16), "#3a5a2c", 1.6, tex=0.6, rim=0.3); c.part(lambda d: ell(d, 24, 26, 8, 6), "#4f7a3c", 1.0); o["bush"] = c.finish()
    return o

def glow(size, color):
    """Textura radial para PointLight2D / efectos de brillo."""
    yy, xx = np.mgrid[:size, :size]; r = np.sqrt((xx - size / 2) ** 2 + (yy - size / 2) ** 2) / (size / 2)
    a = np.clip(1 - r, 0, 1) ** 2.2; rgb = np.broadcast_to(hexc(color), (size, size, 3))
    return Image.fromarray(np.dstack([rgb, a * 255]).astype(np.uint8), "RGBA")

def main():
    for n, im in make_tiles().items(): save(im, "tiles", n + ".png")
    for k, im in enumerate(make_skins()): save(im, "skins", f"skin_{k}.png")
    for fam in M: save(make_monster(fam), "monsters", f"{fam}.png")
    save(make_monster("goblin"), "monsters", "boss_placeholder.png")
    for n, im in make_objects().items(): save(im, "objects", n + ".png")
    save(glow(256, "#ffffff"), "fx", "light_soft.png"); save(glow(256, "#b070ff"), "fx", "glow_purple.png")
    print("HD OK ->", os.path.abspath(OUT))
if __name__ == "__main__": main()
