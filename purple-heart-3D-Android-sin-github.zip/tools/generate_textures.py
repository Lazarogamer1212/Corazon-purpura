#!/usr/bin/env python3
"""Genera texturas pixel-art ORIGINALES (16x16 -> 32x32) para Corazón Púrpura.
Estilo: medieval moderno (piedra oscura, acero frío, acentos púrpura). Licencia: CC0.
Uso: python3 tools/generate_textures.py   (requiere Pillow)"""
import random, os
from PIL import Image, ImageDraw
S = 16; UP = 2
OUT = os.path.join(os.path.dirname(__file__), "..", "assets")

def C(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)
OUTLINE = C("#14111c")
P = dict(stone=C("#4a4858"), stone_d=C("#35333f"), stone_l=C("#615e72"), wood=C("#7a5233"), wood_d=C("#563621"),
         wood_l=C("#98693f"), steel=C("#9aa3b5"), steel_d=C("#6b7488"), steel_l=C("#c9d1e0"), purple=C("#9b4dff"),
         purple_d=C("#5b21a8"), purple_l=C("#d9b3ff"), grass=C("#3f6b3a"), grass_d=C("#2f5230"), dirt=C("#6b5238"),
         sand=C("#b59b63"), ash=C("#3a3340"), water=C("#2d4f7a"), swamp=C("#3b4a2c"), gold=C("#f2c230"), red=C("#a82a2a"),
         skin=C("#e0b48c"), white=C("#f2f2f5"), bone=C("#e8e2cf"), blood=C("#7a1020"))

def new(): return Image.new("RGBA", (S, S), (0,0,0,0))
def save(img, *path):
    p = os.path.join(OUT, *path); os.makedirs(os.path.dirname(p), exist_ok=True)
    img.resize((S*UP, S*UP), Image.NEAREST).save(p)
def noise(img, base, alts, n, rng):
    d = ImageDraw.Draw(img); d.rectangle([0,0,S-1,S-1], fill=base)
    for _ in range(n): d.point((rng.randrange(S), rng.randrange(S)), fill=rng.choice(alts))
def bricks(img, face, mortar, light, rng, w=8, h=4):
    d = ImageDraw.Draw(img); d.rectangle([0,0,S-1,S-1], fill=mortar)
    for r, y in enumerate(range(0, S, h)):
        off = (w//2) if r % 2 else 0
        for x in range(-off, S, w):
            d.rectangle([max(x+1,0), y+1, min(x+w-1,S-1), y+h-1], fill=face)
            d.line([max(x+1,0), y+1, min(x+w-1,S-1), y+1], fill=light)

# ---------------- TILES ----------------
def make_tiles():
    rng = random.Random(7); tiles = {}
    t = new(); bricks(t, P["stone"], P["stone_d"], P["stone_l"], rng); tiles["castle_wall_stone"] = t
    t = new(); noise(t, P["stone_d"], [P["stone"], P["ash"], P["stone"]], 40, rng)
    d = ImageDraw.Draw(t); d.line([0,8,15,8], fill=C("#2a2832")); d.line([8,0,8,15], fill=C("#2a2832")); tiles["castle_floor"] = t
    t = new(); noise(t, P["wood"], [P["wood_d"], P["wood_l"]], 30, rng)
    d = ImageDraw.Draw(t)
    for y in (0,5,10,15): d.line([0,y,15,y], fill=P["wood_d"])
    tiles["wood_floor"] = t
    t = new(); bricks(t, P["wood"], P["wood_d"], P["wood_l"], rng, 16, 4); tiles["wall_wood"] = t
    t = new(); bricks(t, P["steel_d"], C("#3b4152"), P["steel_l"], rng, 8, 4)
    d = ImageDraw.Draw(t)
    for x,y in [(2,2),(10,2),(6,6),(14,6),(2,10),(10,10),(6,14),(14,14)]: d.point((x,y), fill=P["steel_l"])
    tiles["wall_steel"] = t
    t = new(); noise(t, P["grass"], [P["grass_d"], C("#4f8447")], 45, rng); tiles["grass"] = t
    t = new(); noise(t, P["dirt"], [C("#5a432d"), C("#7d6244")], 40, rng); tiles["dirt"] = t
    t = new(); noise(t, P["swamp"], [C("#2c381f"), C("#4f6137"), C("#6b7a3e")], 50, rng); tiles["swamp"] = t
    t = new(); noise(t, P["sand"], [C("#a58a54"), C("#c8b278")], 35, rng); tiles["sand"] = t
    t = new(); noise(t, P["ash"], [C("#2a242f"), C("#52485a"), C("#7a2a1a")], 40, rng); tiles["ashlands"] = t
    t = new(); noise(t, P["water"], [C("#3b6495"), C("#25416a")], 30, rng)
    d = ImageDraw.Draw(t)
    for x,y in [(2,3),(9,7),(4,12)]: d.line([x,y,x+3,y], fill=C("#6c9bd1"))
    tiles["water"] = t
    t = new(); noise(t, C("#3a1c63"), [C("#4a2480"), C("#2e1550")], 30, rng)
    d = ImageDraw.Draw(t); d.rectangle([0,0,15,1], fill=P["gold"]); d.rectangle([0,14,15,15], fill=P["gold"]); tiles["carpet_purple"] = t
    # Puertas
    for name, face, dark, light in [("gate_wood_tile", P["wood"], P["wood_d"], P["wood_l"]), ("gate_steel_tile", P["steel_d"], C("#3b4152"), P["steel_l"])]:
        t = new(); d = ImageDraw.Draw(t); d.rectangle([0,0,15,15], fill=dark)
        for x in range(1,15,4): d.rectangle([x,1,x+2,14], fill=face); d.line([x,1,x,14], fill=light)
        d.rectangle([0,3,15,4], fill=P["steel_d"]); d.rectangle([0,11,15,12], fill=P["steel_d"]); tiles[name] = t
    return tiles

# ---------------- PERSONAJES (skins) ----------------
def humanoid(skin, hair, tunic, pants, boots, extra=None):
    i = new(); d = ImageDraw.Draw(i)
    d.rectangle([5,2,10,7], fill=skin); d.rectangle([5,1,10,3], fill=hair)       # cabeza + pelo
    d.point((6,5), fill=OUTLINE); d.point((9,5), fill=OUTLINE)                    # ojos
    d.rectangle([4,8,11,12], fill=tunic); d.rectangle([3,8,3,11], fill=skin); d.rectangle([12,8,12,11], fill=skin)
    d.rectangle([4,13,11,13], fill=C("#3b2a1a"))                                  # cinturón
    d.rectangle([5,13,6,15], fill=pants); d.rectangle([9,13,10,15], fill=pants)
    d.rectangle([5,15,6,15], fill=boots); d.rectangle([9,15,10,15], fill=boots)
    if extra: extra(d)
    return outline(i)
def outline(img):
    out = img.copy(); px = img.load(); o = out.load()
    for y in range(S):
        for x in range(S):
            if px[x,y][3] == 0:
                for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    nx,ny = x+dx,y+dy
                    if 0<=nx<S and 0<=ny<S and px[nx,ny][3] and px[nx,ny] != OUTLINE: o[x,y] = OUTLINE; break
    return out

def make_skins():
    L = C("#cfcfd8"); sk = [C("#e0b48c"), C("#c68c5a"), C("#8d5a3b"), C("#f1cfae")]
    def hood(d): d.rectangle([4,1,11,3], fill=C("#8b8b98")); d.rectangle([4,4,4,7], fill=C("#8b8b98")); d.rectangle([11,4,11,7], fill=C("#8b8b98"))
    def helm(d): d.rectangle([4,1,11,4], fill=P["steel"]); d.rectangle([7,1,8,2], fill=P["steel_l"]); d.rectangle([4,5,4,6], fill=P["steel_d"]); d.rectangle([11,5,11,6], fill=P["steel_d"])
    def crown(d): d.rectangle([5,0,10,0], fill=P["gold"]); [d.point((x,-0+0), fill=P["gold"]) for x in (5,7,9)]
    def cape(d): d.rectangle([3,8,3,14], fill=P["purple_d"]); d.rectangle([12,8,12,14], fill=P["purple_d"])
    def hat(d): d.rectangle([3,1,12,1], fill=C("#5b3d7a")); d.rectangle([5,-0,10,0], fill=C("#5b3d7a"))
    def horns(d): d.point((4,1), fill=P["bone"]); d.point((11,1), fill=P["bone"]); d.point((4,0), fill=P["bone"]); d.point((11,0), fill=P["bone"])
    def scarf(d): d.rectangle([5,8,10,8], fill=P["red"])
    skins = [humanoid(sk[0], C("#4a3020"), L, C("#5a5a68"), C("#2a2a2a")),
             humanoid(sk[1], C("#1a1a1a"), L, C("#4a4a58"), C("#3b2a1a"), scarf),
             humanoid(sk[2], C("#2a1a10"), L, C("#5a5a68"), C("#2a2a2a"), helm),
             humanoid(sk[3], C("#d8b45a"), L, C("#55556a"), C("#3b2a1a"), cape),
             humanoid(sk[0], C("#8a8a95"), L, C("#4a4a58"), C("#2a2a2a"), hood),
             humanoid(sk[1], C("#a8321e"), L, C("#5a5a68"), C("#3b2a1a"), horns),
             humanoid(sk[2], C("#101010"), L, C("#4a4a58"), C("#2a2a2a"), hat),
             humanoid(sk[3], C("#7a5a3a"), L, C("#5a5a68"), C("#2a2a2a"), lambda d: (cape(d), crown(d)))]
    return skins

# ---------------- MONSTRUOS (30 familias) ----------------
def body_humanoid(c, c2, eye):
    i = new(); d = ImageDraw.Draw(i)
    d.rectangle([5,2,10,7], fill=c); d.rectangle([4,8,11,12], fill=c2); d.rectangle([2,8,3,12], fill=c); d.rectangle([12,8,13,12], fill=c)
    d.rectangle([5,13,6,15], fill=c); d.rectangle([9,13,10,15], fill=c)
    d.point((6,4), fill=eye); d.point((9,4), fill=eye); return i
def body_beast(c, c2, eye):
    i = new(); d = ImageDraw.Draw(i)
    d.rectangle([3,6,12,11], fill=c); d.rectangle([11,4,15,8], fill=c); d.rectangle([2,11,3,15], fill=c2); d.rectangle([5,11,6,15], fill=c2)
    d.rectangle([9,11,10,15], fill=c2); d.rectangle([12,11,13,15], fill=c2); d.rectangle([0,6,2,7], fill=c2); d.point((13,5), fill=eye); d.point((12,4), fill=c2); return i
def body_flyer(c, c2, eye):
    i = new(); d = ImageDraw.Draw(i)
    d.rectangle([6,5,9,11], fill=c); d.polygon([(6,6),(0,3),(1,9),(6,10)], fill=c2); d.polygon([(9,6),(15,3),(14,9),(9,10)], fill=c2)
    d.point((7,7), fill=eye); d.point((8,7), fill=eye); return i
def body_blob(c, c2, eye):
    i = new(); d = ImageDraw.Draw(i)
    d.ellipse([2,5,13,15], fill=c); d.ellipse([4,6,8,9], fill=c2); d.point((6,10), fill=eye); d.point((10,10), fill=eye); return i
def body_big(c, c2, eye):
    i = new(); d = ImageDraw.Draw(i)
    d.rectangle([4,1,11,6], fill=c); d.rectangle([2,7,13,12], fill=c2); d.rectangle([0,7,1,13], fill=c); d.rectangle([14,7,15,13], fill=c)
    d.rectangle([3,13,6,15], fill=c); d.rectangle([9,13,12,15], fill=c); d.point((6,3), fill=eye); d.point((9,3), fill=eye); return i
def body_snake(c, c2, eye):
    i = new(); d = ImageDraw.Draw(i)
    for k,(x,y) in enumerate([(2,12),(4,13),(6,12),(8,11),(10,12),(12,11)]): d.rectangle([x,y,x+2,y+2], fill=c if k%2 else c2)
    d.rectangle([11,7,14,10], fill=c); d.point((13,8), fill=eye); return i
def body_spider(c, c2, eye):
    i = new(); d = ImageDraw.Draw(i)
    d.ellipse([5,6,10,11], fill=c)
    for y in (6,8,10,12): d.line([0,y-2,5,y], fill=c2); d.line([15,y-2,10,y], fill=c2)
    d.point((7,8), fill=eye); d.point((9,8), fill=eye); return i

M = {  # familia: (plantilla, color, color2, ojos, decoración)
 "skeleton":("humanoid","#e8e2cf","#cfc8b0","#ff3030",None), "zombie":("humanoid","#6f8f5a","#4a5a3a","#ffe040",None),
 "vampire":("humanoid","#d8c8d0","#5a1020","#ff2020","fangs"), "bat":("flyer","#3a3048","#2a2236","#ff2020",None),
 "wraith":("humanoid","#9fb4d8","#6e86b0","#ffffff","ghost"), "ghoul":("humanoid","#8a8f78","#5e6350","#ff9a20",None),
 "werewolf":("beast","#6b5a4a","#4a3c30","#ffd020",None), "spider":("spider","#2a2a30","#4a4a55","#ff2020",None),
 "goblin":("humanoid","#6aa84f","#4a7a38","#ffe040","small"), "orc":("big","#4f7a3c","#3a5a2c","#ff4040",None),
 "troll":("big","#6a7a5a","#4a5a40","#ffe040",None), "imp":("humanoid","#c0392b","#8a2418","#ffe040","horns"),
 "harpy":("flyer","#a07a5a","#6e4e36","#ffe040",None), "golem":("big","#7a7a88","#55555f","#9b4dff",None),
 "slime":("blob","#4fc46a","#9be8ab","#101010",None), "cultist":("humanoid","#3a2a55","#2a1a40","#ff3030","hood"),
 "gargoyle":("big","#6a6a78","#4a4a56","#ff3030",None), "banshee":("humanoid","#cfe4ff","#9fb8e0","#40a0ff","ghost"),
 "lich":("humanoid","#d8d8c0","#3a1c63","#9b4dff","crown"), "demon":("big","#a82a2a","#6a1a1a","#ffe040","horns"),
 "wyrm":("snake","#3f7a4a","#2a5a34","#ffe040",None), "mummy":("humanoid","#d8cfa8","#b8ae88","#ff3030",None),
 "scorpion":("spider","#b58a3a","#8a6422","#101010",None), "knight_fallen":("humanoid","#6b7488","#3b4152","#ff3030","helm"),
 "treant":("big","#5a4228","#2f5230","#ffe040",None), "hound":("beast","#2a2a30","#7a1a1a","#ff6020",None),
 "witch":("humanoid","#6a8a5a","#3a1c63","#a0ff40","hat"), "shade":("humanoid","#2a2236","#1a1424","#9b4dff","ghost"),
 "drake":("beast","#a83a2a","#6a2218","#ffe040","wings"), "abomination":("big","#7a5a6a","#5a1a3a","#ff3030","extra_eyes"),
}
def make_monster(fam):
    t, c, c2, eye, deco = M[fam]; c, c2, eye = C(c), C(c2), C(eye)
    img = {"humanoid":body_humanoid,"beast":body_beast,"flyer":body_flyer,"blob":body_blob,"big":body_big,"snake":body_snake,"spider":body_spider}[t](c, c2, eye)
    d = ImageDraw.Draw(img)
    if deco == "fangs": d.point((6,6), fill=P["white"]); d.point((9,6), fill=P["white"])
    elif deco == "horns": d.point((4,1), fill=P["bone"]); d.point((11,1), fill=P["bone"]); d.point((5,2), fill=P["bone"]); d.point((10,2), fill=P["bone"])
    elif deco == "hood": d.rectangle([4,1,11,3], fill=c2)
    elif deco == "helm": d.rectangle([4,1,11,3], fill=P["steel_d"])
    elif deco == "hat": d.rectangle([3,2,12,2], fill=c2); d.rectangle([6,0,9,1], fill=c2)
    elif deco == "crown": d.rectangle([5,1,10,1], fill=P["gold"])
    elif deco == "wings": d.polygon([(3,6),(0,2),(5,7)], fill=c2); d.polygon([(10,6),(13,2),(8,7)], fill=c2)
    elif deco == "extra_eyes": d.point((7,2), fill=eye); d.point((8,2), fill=eye); d.point((7,5), fill=eye)
    elif deco == "ghost":
        px = img.load()
        for y in range(S):
            for x in range(S):
                if px[x,y][3] and y >= 12: px[x,y] = (px[x,y][0], px[x,y][1], px[x,y][2], 140)
    elif deco == "small":
        img = img.crop((0,0,S,S)); small = img.resize((12,12), Image.NEAREST); img = new(); img.paste(small, (2,4), small)
    return outline(img)

# ---------------- OBJETOS ----------------
def make_objects():
    o = {}
    i = new(); d = ImageDraw.Draw(i)                        # Corazón: esmeralda púrpura
    d.rectangle([3,12,12,15], fill=P["stone_l"]); d.rectangle([2,14,13,15], fill=P["stone"])
    d.polygon([(8,0),(13,4),(13,9),(8,13),(3,9),(3,4)], fill=P["purple"])
    d.polygon([(8,0),(3,4),(8,6)], fill=P["purple_l"]); d.polygon([(8,6),(3,4),(3,9),(8,13)], fill=P["purple_d"])
    d.point((6,3), fill=P["white"]); d.point((5,5), fill=P["white"]); o["castle_heart"] = outline(i)
    i = new(); d = ImageDraw.Draw(i)                        # cabaña
    d.rectangle([2,7,13,14], fill=P["wood"]); d.polygon([(0,8),(8,1),(15,8)], fill=C("#8a3a2a")); d.rectangle([6,10,9,14], fill=P["wood_d"])
    d.rectangle([3,9,4,10], fill=C("#9fd0ff")); d.rectangle([11,9,12,10], fill=C("#9fd0ff")); o["cabin"] = outline(i)
    i = new(); d = ImageDraw.Draw(i)                        # mochila
    d.rectangle([4,5,11,14], fill=C("#8a5a2f")); d.rectangle([5,2,10,5], fill=C("#6a4422")); d.rectangle([4,9,11,10], fill=P["wood_d"]); d.rectangle([7,8,8,11], fill=P["gold"]); o["backpack"] = outline(i)
    i = new(); d = ImageDraw.Draw(i)                        # ajo
    for x in (3,7,11):
        d.ellipse([x,8,x+3,13], fill=P["white"]); d.line([x+1,3,x+1,8], fill=P["grass"])
    d.rectangle([0,14,15,15], fill=P["dirt"]); o["garlic"] = outline(i)
    i = new(); d = ImageDraw.Draw(i)                        # torreta de estacas
    d.rectangle([3,10,12,15], fill=P["stone"]); d.rectangle([4,9,11,9], fill=P["stone_l"])
    for x in (4,7,10): d.polygon([(x,9),(x+1,2),(x+2,9)], fill=P["wood_l"])
    o["stake_turret"] = outline(i)
    i = new(); d = ImageDraw.Draw(i)                        # caballo
    d.rectangle([2,6,11,10], fill=C("#8a5a3a")); d.rectangle([10,2,13,7], fill=C("#8a5a3a")); d.rectangle([13,3,15,5], fill=C("#6a4326")); d.point((12,3), fill=OUTLINE)
    for x in (2,4,9,11): d.rectangle([x,10,x+1,15], fill=C("#6a4326"))
    d.rectangle([0,5,2,7], fill=C("#2a1a10")); d.rectangle([9,1,10,6], fill=C("#2a1a10")); o["horse"] = outline(i)
    i = new(); d = ImageDraw.Draw(i)                        # caballo con barda
    i = o["horse"].copy(); d = ImageDraw.Draw(i); d.rectangle([4,6,9,9], fill=P["steel"]); d.rectangle([5,6,8,7], fill=P["steel_l"]); d.rectangle([11,3,12,5], fill=P["steel_d"]); o["horse_armored"] = outline(i)
    s = humanoid(C("#e0b48c"), C("#3a2a1a"), C("#2f4f8a"), C("#4a4a58"), C("#2a2a2a"), lambda d: (d.rectangle([4,1,11,4], fill=P["steel"]), d.rectangle([0,7,2,13], fill=P["steel_d"]), d.rectangle([13,5,13,12], fill=P["steel_l"])))
    o["soldier"] = s
    npc = humanoid(C("#e0b48c"), C("#d8d8d8"), C("#7a3a2a"), C("#4a3a2a"), C("#2a2a2a"), lambda d: (d.rectangle([7,-1+0,8,0], fill=P["gold"]))); d = ImageDraw.Draw(npc); d.point((8,-1+1), fill=P["gold"]); o["npc_quest"] = npc
    i = new(); d = ImageDraw.Draw(i); d.ellipse([3,3,12,12], fill=P["gold"]); d.ellipse([5,5,10,10], outline=C("#b8860b")); d.point((6,5), fill=P["white"]); o["gold_coin"] = outline(i)
    i = new(); d = ImageDraw.Draw(i); d.rectangle([2,6,13,14], fill=P["wood"]); d.rectangle([2,4,13,7], fill=P["wood_l"]); d.rectangle([2,9,13,9], fill=P["steel_d"]); d.rectangle([7,8,8,10], fill=P["gold"]); o["chest"] = outline(i)
    i = new(); d = ImageDraw.Draw(i); d.rectangle([7,8,8,15], fill=P["wood_d"]); d.ellipse([1,0,14,10], fill=P["grass_d"]); d.ellipse([3,1,9,6], fill=C("#4f8447")); o["tree"] = outline(i)
    i = new(); d = ImageDraw.Draw(i); d.rectangle([5,3,10,12], fill=C("#8a4a2a")); d.ellipse([5,3,10,8], fill=C("#a85a34")); d.rectangle([9,2,12,3], fill=P["bone"]); o["food_meat"] = outline(i)
    return o

def main():
    rng = random.Random(1)
    tiles = make_tiles()
    for n, im in tiles.items(): save(im, "tiles", n + ".png")
    atlas = Image.new("RGBA", (S*len(tiles), S))
    for k, im in enumerate(tiles.values()): atlas.paste(im, (k*S, 0))
    atlas.resize((S*UP*len(tiles), S*UP), Image.NEAREST).save(os.path.join(OUT, "tiles", "tileset_atlas.png"))
    with open(os.path.join(OUT, "tiles", "tileset_atlas.txt"), "w") as f:
        for k, n in enumerate(tiles): f.write(f"{k}\t{n}\n")
    for k, im in enumerate(make_skins()): save(im, "skins", f"skin_{k}.png")
    for fam in M: save(make_monster(fam), "sprites", "monsters", f"{fam}.png")
    save(make_monster("goblin"), "sprites", "monsters", "boss_placeholder.png")
    for n, im in make_objects().items(): save(im, "sprites", "objects", n + ".png")
    print("Texturas generadas en", os.path.abspath(OUT))
if __name__ == "__main__": main()
