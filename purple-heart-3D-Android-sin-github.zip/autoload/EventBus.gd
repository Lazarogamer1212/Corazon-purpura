extends Node
## Bus global de señales: desacopla sistemas (UI, red, combate, castillo).
signal damage_dealt(target_path: NodePath, amount: int, is_crit: bool)
signal entity_died(entity_path: NodePath, killer_peer: int)
signal monster_killed(peer_id: int, monster_id: String, rarity: String)
signal gold_changed(total: int)
signal heart_hp_changed(hp: int, max_hp: int)
signal game_over(reason: String)
signal wave_started(n: int, boss: bool)
signal quest_updated(peer_id: int, quest_id: String)
signal level_up(peer_id: int, new_level: int)
signal skill_unlocked(peer_id: int, skill_id: String)
