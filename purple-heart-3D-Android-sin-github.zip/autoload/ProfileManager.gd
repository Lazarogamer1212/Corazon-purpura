extends Node
## Perfil persistente del jugador (nombre, skin, clase, progreso).
const SAVE_PATH := "user://profile.json"

var data := {
	"name": "", "skin_id": 0, "skin_color": "#ffffff",
	"class_id": "warrior", "level": 1, "xp": 0, "int_stat": 1,
	"skill_points": 0, "unlocked_skills": [], "gold_personal": 0,
	"has_seen_intro": false,
}

func exists() -> bool: return FileAccess.file_exists(SAVE_PATH)

func create(player_name: String, skin_id: int, color: Color, class_id: String) -> void:
	data.name = player_name.strip_edges().left(16)
	data.skin_id = skin_id
	data.skin_color = color.to_html()
	data.class_id = class_id
	save()

func save() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	f.store_string(JSON.stringify(data))

func load_profile() -> bool:
	if not exists(): return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if parsed is Dictionary:
		data.merge(parsed, true)
		return true
	return false

## Datos que se comparten con los demás jugadores en la LAN.
func public_data() -> Dictionary:
	return {"name": data.name, "skin_id": data.skin_id, "skin_color": data.skin_color,
		"class_id": data.class_id, "level": data.level}
