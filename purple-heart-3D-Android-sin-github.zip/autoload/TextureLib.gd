extends Node
## Biblioteca central de texturas. Estilo "hd" (64px, relieve y sombras, vista cenital) con
## respaldo automático al estilo "pixel". Para usar otro pack (p. ej. Kenney CC0) solo toca este archivo.
enum Style { HD, PIXEL }
var style: Style = Style.HD
var _cache: Dictionary = {}

func _dir() -> String: return "res://assets/hd/" if style == Style.HD else "res://assets/"
func _load(path: String) -> Texture2D:
	if _cache.has(path): return _cache[path]
	var tex: Texture2D = load(path) if ResourceLoader.exists(path) else null
	_cache[path] = tex
	return tex

func skin(id: int) -> Texture2D:
	return _load(_dir() + "skins/skin_%d.png" % id) if style == Style.HD else _load("res://assets/skins/skin_%d.png" % id)
func monster(family: String) -> Texture2D:
	var p := "monsters/%s.png" % family if style == Style.HD else "sprites/monsters/%s.png" % family
	var t := _load(_dir() + p)
	return t if t else _load(_dir() + ("monsters/boss_placeholder.png" if style == Style.HD else "sprites/monsters/boss_placeholder.png"))
func object(name: String) -> Texture2D:
	return _load(_dir() + ("objects/%s.png" % name if style == Style.HD else "sprites/objects/%s.png" % name))
func tile(name: String) -> Texture2D: return _load(_dir() + "tiles/%s.png" % name)
func fx(name: String) -> Texture2D:   return _load("res://assets/hd/fx/%s.png" % name)

## Orden de tiles para el TileSet (nombres de archivo en assets/hd/tiles).
const TILE_NAMES := ["castle_wall_stone","castle_floor","wood_floor","wall_wood","wall_steel","grass","dirt","swamp",
	"sand","ashlands","water","carpet_purple","gate_wood_tile","gate_steel_tile"]

## TileSet en tiempo de ejecución, un tile por textura (colisión: añade en el editor para muros).
func build_tileset() -> TileSet:
	var ts := TileSet.new(); ts.tile_size = Vector2i(64, 64)
	var atlas := Image.create(64 * TILE_NAMES.size(), 64, false, Image.FORMAT_RGBA8)
	for i in TILE_NAMES.size():
		var t := tile(TILE_NAMES[i])
		if t: atlas.blit_rect(t.get_image(), Rect2i(0, 0, 64, 64), Vector2i(i * 64, 0))
	var src := TileSetAtlasSource.new()
	src.texture = ImageTexture.create_from_image(atlas); src.texture_region_size = Vector2i(64, 64)
	for i in TILE_NAMES.size(): src.create_tile(Vector2i(i, 0))
	ts.add_source(src, 0)
	return ts
