extends Node
## Red LAN: ENet (host autoritativo) + descubrimiento por broadcast UDP.
## El anfitrión es el servidor Y un jugador. 3–10 jugadores.
const PORT := 7777
const DISCOVERY_PORT := 45454
const MAX_PLAYERS := 10
const MIN_PLAYERS := 3   # mínimo recomendado para iniciar (configurable)

signal player_joined(peer_id: int, profile: Dictionary)
signal player_left(peer_id: int)
signal server_found(ip: String, info: Dictionary)

var players: Dictionary = {}   # peer_id -> perfil público
var _udp_listen: PacketPeerUDP
var _udp_broadcast: PacketPeerUDP
var _bc_timer := 0.0
var hosting := false

func host_game(server_name: String) -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PLAYERS)
	if err != OK: return err
	multiplayer.multiplayer_peer = peer
	hosting = true
	_udp_broadcast = PacketPeerUDP.new()
	_udp_broadcast.set_broadcast_enabled(true)
	_udp_broadcast.set_dest_address("255.255.255.255", DISCOVERY_PORT)
	multiplayer.peer_connected.connect(func(id): pass)
	multiplayer.peer_disconnected.connect(_on_peer_left)
	players[1] = Profile.public_data()
	set_meta("server_name", server_name)
	return OK

func join_game(ip: String) -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK: return err
	multiplayer.multiplayer_peer = peer
	multiplayer.connected_to_server.connect(func(): _register.rpc_id(1, Profile.public_data()))
	multiplayer.peer_disconnected.connect(_on_peer_left)
	return OK

func start_discovery() -> void:
	_udp_listen = PacketPeerUDP.new()
	_udp_listen.bind(DISCOVERY_PORT)

func _process(delta: float) -> void:
	if hosting and _udp_broadcast:
		_bc_timer += delta
		if _bc_timer >= 1.0:
			_bc_timer = 0
			var info := {"name": get_meta("server_name", "Castillo"), "players": players.size()}
			_udp_broadcast.put_packet(JSON.stringify(info).to_utf8_buffer())
	if _udp_listen and _udp_listen.get_available_packet_count() > 0:
		var ip := _udp_listen.get_packet_ip()
		var data = JSON.parse_string(_udp_listen.get_packet().get_string_from_utf8())
		if data is Dictionary: server_found.emit(ip, data)

@rpc("any_peer", "reliable")
func _register(profile: Dictionary) -> void:
	if not multiplayer.is_server(): return
	var id := multiplayer.get_remote_sender_id()
	if players.size() >= MAX_PLAYERS: return
	players[id] = profile
	_sync_players.rpc(players)
	player_joined.emit(id, profile)

@rpc("authority", "call_local", "reliable")
func _sync_players(all: Dictionary) -> void:
	players = all

func _on_peer_left(id: int) -> void:
	players.erase(id)
	player_left.emit(id)
