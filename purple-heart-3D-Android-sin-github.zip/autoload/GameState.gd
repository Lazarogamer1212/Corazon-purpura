extends Node
## Estado global de la partida. El servidor es la autoridad.
## PERMADEATH DE PARTIDA: si el Corazón cae, se borra el progreso de la run.
enum Phase { LOBBY, PLAYING, GAME_OVER }
var phase: Phase = Phase.LOBBY
var day := 1
var run_seed := 0

func start_run() -> void:
	if not multiplayer.is_server(): return
	run_seed = randi()
	phase = Phase.PLAYING
	_sync_phase.rpc(phase, run_seed)

@rpc("authority", "call_local", "reliable")
func _sync_phase(p: int, seed_: int) -> void:
	phase = p as Phase
	run_seed = seed_
	seed(seed_)

func trigger_game_over(reason: String) -> void:
	if not multiplayer.is_server(): return
	_game_over.rpc(reason)

@rpc("authority", "call_local", "reliable")
func _game_over(reason: String) -> void:
	phase = Phase.GAME_OVER
	# Se pierde TODO el progreso de la partida (inventario, niveles, oro, construcciones)
	Profile.data.level = 1
	Profile.data.xp = 0
	Profile.data.skill_points = 0
	Profile.data.unlocked_skills = []
	Profile.data.gold_personal = 0
	Profile.save()
	EventBus.game_over.emit(reason)
