# Créditos y licencias de texturas

## Texturas incluidas (originales)
Todo lo que hay en `assets/tiles`, `assets/skins`, `assets/sprites` fue **generado por código**
(`tools/generate_textures.py`) para este proyecto. Son obras originales publicadas como **CC0 1.0 (dominio público)**:
puedes usarlas, modificarlas y venderlas sin atribución. Para regenerarlas o ajustar la paleta:
`pip install pillow && python3 tools/generate_textures.py`

## Estilo HD (por defecto) — `assets/hd/`
Generado por `tools/generate_hd_textures.py` (Pillow + NumPy). Originales, CC0. 64x64, vista cenital con relieve, sombra proyectada
y luz desde arriba-izquierda. Personajes/monstruos **miran a la derecha** (+X) para rotar el Sprite2D hacia su movimiento.
Cambiar de estilo: `TextureLib.style = TextureLib.Style.PIXEL` (conserva el set pixel-art original).

## Packs públicos (CC0) recomendados para mejorar el arte
Verificados como CC0 1.0. No incluidos en el repo (descárgalos tú):
| Pack | Autor | Contenido | Enlace |
|---|---|---|---|
| Tiny Dungeon | Kenney | +130 sprites: tiles de mazmorra, armas, objetos, personajes | https://kenney-assets.itch.io/tiny-dungeon |
| Tiny Creatures | Clint Bellanger (con permiso de Kenney) | +100 monstruos y +50 animales 16x16 | https://clintbellanger.itch.io/tiny-creatures |
| Topdown Shooter | Kenney | Tiles, jugadores, enemigos y objetos en **vista cenital** (CC0, verificado) | https://opengameart.org/content/topdown-shooter |
| Más packs Kenney "Tiny" | Kenney | Tiny Town (ciudades), etc. | https://kenney.nl/assets/series:Tiny |

Ambos packs son 16x16 con contorno grueso: compatibles entre sí. **Cómo cambiar:** copia los PNG a `assets/`
y edita solo `autoload/TextureLib.gd` (rutas por nombre). Mantén `default_texture_filter=0` (Nearest) para pixel art nítido.
Evita packs CC-BY / CC-BY-SA (p. ej. LPC) si quieres publicar sin obligaciones de atribución.
