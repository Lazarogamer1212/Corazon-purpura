# 💜 Corazón Púrpura — Reinos 3D (Android)

Esta versión reemplaza la presentación pixel-art por un **mundo 3D procedural** pensado para móviles Android. La base original se conserva en el repositorio, pero la escena de inicio ahora es `scenes/3d/Main3D.tscn`.

## Qué se añadió

- Mundo 3D amplio de 260 × 260 metros.
- Cámara tercera persona/isométrica suave.
- Personaje 3D construido con mallas y materiales PBR.
- Castillo central con Corazón Púrpura luminoso.
- Aldeas, caminos, ruinas, agua y zonas de bosque.
- Árboles con movimiento por viento.
- Hierba animada mediante shader, no GIF.
- Animación ambiental continua.
- Animales con comportamiento de deambulación.
- Enemigos con IA de persecución y ataque.
- Luciérnagas con movimiento orbital y luz.
- Mariposas con vuelo procedural.
- Antorchas con PointLight3D, sombras y parpadeo.
- Ciclo día/noche y niebla atmosférica.
- Sombras dinámicas del sol y luces locales.
- Barra de vida/maná.
- Barra inferior de 6 poderes inspirada en MMORPG clásicos, adaptada a móvil.
- Controles táctiles de movimiento.
- Habilidades con enfriamiento.
- Arquitectura preparada para ampliar combate, inventario, monturas, misiones, jefes y multijugador.

## Motor

**Godot 4.3**, renderer **Mobile**, Android ARM64.

El proyecto mantiene la configuración de exportación Android de la base original.

## Abrir y probar

1. Instala Godot 4.3.
2. Abre este directorio como proyecto.
3. Ejecuta `scenes/3d/Main3D.tscn`.
4. Para Android usa el preset `Android`.

No necesita paquetes externos para arrancar la demo 3D.

## Controles

- Flechas/joystick táctil: movimiento.
- Barra inferior: habilidades 1–6.
- `Enter` en escritorio: correr.
- La cámara sigue automáticamente al héroe.

## IA y animación

La fauna y enemigos no son secuencias de imágenes. Cada entidad se actualiza por frame con estado, dirección, velocidad, objetivo y reacción:

- fauna: movimiento errante;
- enemigos: adquisición del jugador como objetivo;
- ataque por proximidad;
- variación de velocidad;
- bobbing procedural;
- mariposas/luciérnagas: trayectorias independientes;
- árboles/hierba: shader de viento;
- antorchas: variación de energía y rango de luz;
- sol: ciclo día/noche.

## Rendimiento Android

El proyecto utiliza el renderer Mobile y mantiene un número moderado de entidades 3D. La siguiente fase recomendada para un mapa todavía mayor es pasar árboles, hierba y decoración a `MultiMeshInstance3D`, implementar LOD y cargar el mundo por chunks.

## GitHub Actions

El workflow está en:

`.github/workflows/build-android.yml`

Al hacer push a `main`/`master`, GitHub Actions intenta producir:

`PurpleHeart-android-apk`

También puedes ejecutarlo manualmente desde **Actions → Build Android APK → Run workflow**.

Para Google Play sustituye la firma debug por tu propio keystore y genera AAB release.

## Próxima expansión recomendada

1. Inventario visual 3D.
2. Loot con rarezas y estadísticas.
3. Jefes 3D con fases.
4. Mazmorras interiores.
5. Monturas.
6. Sistema de misiones con NPC.
7. Árbol de habilidades real.
8. Multiplayer LAN autoritativo.
9. Guardado de mundo.
10. LOD/chunks para llevar el mapa mucho más lejos sin sacrificar FPS.

> Nota: las mallas 3D de esta actualización son generadas por código para que el proyecto pueda compilar inmediatamente sin depender de un paquete 3D externo. Se pueden sustituir después por modelos `.glb/.gltf` de mayor detalle sin cambiar la arquitectura principal.
